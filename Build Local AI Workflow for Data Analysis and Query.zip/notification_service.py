import logging
import threading
import time
from datetime import datetime
import json
import os

logger = logging.getLogger(__name__)

try:
    from plyer import notification
    PLYER_AVAILABLE = True
except ImportError:
    PLYER_AVAILABLE = False
    logger.warning("plyer not available. Notifications will be logged only.")

class NotificationService:
    """Service for sending system notifications"""
    
    def __init__(self):
        self.notification_queue = []
        self.queue_lock = threading.Lock()
        self.is_running = False
        self.notification_thread = None
        self.settings = self.load_settings()
        
    def load_settings(self):
        """Load notification settings"""
        default_settings = {
            'enabled': True,
            'show_file_processed': True,
            'show_analysis_complete': True,
            'show_errors': True,
            'show_system_events': True,
            'timeout': 5,  # seconds
            'max_notifications_per_minute': 10
        }
        
        # In a full implementation, you'd load from database or config file
        return default_settings
        
    def start(self):
        """Start the notification service"""
        if not self.is_running:
            self.is_running = True
            self.notification_thread = threading.Thread(target=self._process_notifications, daemon=True)
            self.notification_thread.start()
            logger.info("Notification service started")
            
    def stop(self):
        """Stop the notification service"""
        self.is_running = False
        if self.notification_thread:
            self.notification_thread.join(timeout=5)
        logger.info("Notification service stopped")
        
    def send_notification(self, title, message, notification_type="info", timeout=None):
        """Send a notification"""
        try:
            if not self.settings['enabled']:
                return
                
            # Check if this type of notification is enabled
            if notification_type == "file_processed" and not self.settings['show_file_processed']:
                return
            elif notification_type == "analysis_complete" and not self.settings['show_analysis_complete']:
                return
            elif notification_type == "error" and not self.settings['show_errors']:
                return
            elif notification_type == "system" and not self.settings['show_system_events']:
                return
            
            notification_data = {
                'title': title,
                'message': message,
                'type': notification_type,
                'timestamp': datetime.utcnow(),
                'timeout': timeout or self.settings['timeout']
            }
            
            with self.queue_lock:
                self.notification_queue.append(notification_data)
                
            logger.info(f"Notification queued: {title} - {message}")
            
        except Exception as e:
            logger.error(f"Error sending notification: {e}")
            
    def _process_notifications(self):
        """Process notification queue"""
        last_minute_count = 0
        last_minute_start = time.time()
        
        while self.is_running:
            try:
                current_time = time.time()
                
                # Reset counter every minute
                if current_time - last_minute_start >= 60:
                    last_minute_count = 0
                    last_minute_start = current_time
                
                with self.queue_lock:
                    if self.notification_queue and last_minute_count < self.settings['max_notifications_per_minute']:
                        notification_data = self.notification_queue.pop(0)
                        
                        # Show the notification
                        self._show_notification(notification_data)
                        last_minute_count += 1
                
                time.sleep(1)  # Check queue every second
                
            except Exception as e:
                logger.error(f"Error processing notifications: {e}")
                time.sleep(5)  # Wait longer on error
                
    def _show_notification(self, notification_data):
        """Show a single notification"""
        try:
            title = notification_data['title']
            message = notification_data['message']
            timeout = notification_data['timeout']
            
            if PLYER_AVAILABLE:
                # Use plyer for cross-platform notifications
                notification.notify(
                    title=title,
                    message=message,
                    app_name="AI Data Analyzer",
                    timeout=timeout
                )
                logger.info(f"Notification shown: {title}")
            else:
                # Fallback: just log the notification
                logger.info(f"NOTIFICATION: {title} - {message}")
                
        except Exception as e:
            logger.error(f"Error showing notification: {e}")
            
    def send_file_processed_notification(self, filename, analysis_success=True):
        """Send notification for processed file"""
        if analysis_success:
            self.send_notification(
                "File Processed",
                f"Successfully analyzed: {filename}",
                "file_processed"
            )
        else:
            self.send_notification(
                "File Processing Failed",
                f"Could not analyze: {filename}",
                "error"
            )
            
    def send_analysis_complete_notification(self, files_count, success_count):
        """Send notification for batch analysis completion"""
        if success_count == files_count:
            message = f"Successfully analyzed {files_count} files"
        else:
            message = f"Analyzed {success_count} of {files_count} files"
            
        self.send_notification(
            "Analysis Complete",
            message,
            "analysis_complete"
        )
        
    def send_error_notification(self, error_message):
        """Send error notification"""
        self.send_notification(
            "System Error",
            error_message,
            "error"
        )
        
    def send_system_notification(self, message):
        """Send system event notification"""
        self.send_notification(
            "AI Data Analyzer",
            message,
            "system"
        )
        
    def send_directory_watch_notification(self, directory, action):
        """Send notification for directory watching events"""
        if action == "added":
            message = f"Now watching directory: {directory}"
        elif action == "removed":
            message = f"Stopped watching directory: {directory}"
        else:
            message = f"Directory watch {action}: {directory}"
            
        self.send_notification(
            "Directory Watcher",
            message,
            "system"
        )
        
    def update_settings(self, new_settings):
        """Update notification settings"""
        try:
            self.settings.update(new_settings)
            # In a full implementation, you'd save to database or config file
            logger.info("Notification settings updated")
            return True
        except Exception as e:
            logger.error(f"Error updating notification settings: {e}")
            return False
            
    def get_settings(self):
        """Get current notification settings"""
        return self.settings.copy()
        
    def test_notification(self):
        """Send a test notification"""
        self.send_notification(
            "Test Notification",
            "AI Data Analyzer notification system is working!",
            "system"
        )
        
    def get_notification_history(self, limit=50):
        """Get recent notification history"""
        # In a full implementation, you'd store notifications in database
        # For now, return empty list
        return []
        
    def clear_notification_history(self):
        """Clear notification history"""
        # In a full implementation, you'd clear from database
        logger.info("Notification history cleared")
        return True

