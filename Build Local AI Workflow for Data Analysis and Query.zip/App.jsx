import { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from '@/components/ui/sonner'
import Sidebar from './components/Sidebar'
import Dashboard from './components/Dashboard'
import FileManager from './components/FileManager'
import ChatInterface from './components/ChatInterface'
import SearchResults from './components/SearchResults'
import Settings from './components/Settings'
import './App.css'

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [systemStats, setSystemStats] = useState({
    totalFiles: 0,
    analyzedFiles: 0,
    documentCount: 0,
    imageCount: 0,
    videoCount: 0
  })

  useEffect(() => {
    // Fetch initial system stats
    fetchSystemStats()
  }, [])

  const fetchSystemStats = async () => {
    try {
      const response = await fetch('/api/files/stats')
      if (response.ok) {
        const stats = await response.json()
        setSystemStats(stats)
      }
    } catch (error) {
      console.error('Failed to fetch system stats:', error)
    }
  }

  return (
    <Router>
      <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
        <Sidebar 
          isOpen={sidebarOpen} 
          onToggle={() => setSidebarOpen(!sidebarOpen)}
          stats={systemStats}
        />
        
        <main className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-16'}`}>
          <div className="h-full overflow-auto">
            <Routes>
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route 
                path="/dashboard" 
                element={<Dashboard stats={systemStats} onStatsUpdate={fetchSystemStats} />} 
              />
              <Route 
                path="/files" 
                element={<FileManager onStatsUpdate={fetchSystemStats} />} 
              />
              <Route path="/chat" element={<ChatInterface />} />
              <Route path="/search" element={<SearchResults />} />
              <Route path="/settings" element={<Settings />} />
            </Routes>
          </div>
        </main>
        
        <Toaster position="top-right" />
      </div>
    </Router>
  )
}

export default App

