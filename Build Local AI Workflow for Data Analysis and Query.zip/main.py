import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory
from flask_cors import CORS
from src.models.user import db
from src.routes.user import user_bp
from src.routes.files import files_bp
from src.routes.analysis import analysis_bp
from src.routes.chat import chat_bp

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'ai_data_analyzer_secret_key_2024'

# Enable CORS for all routes
CORS(app, origins="*")

# Register blueprints
app.register_blueprint(user_bp, url_prefix='/api')
app.register_blueprint(files_bp, url_prefix='/api')
app.register_blueprint(analysis_bp, url_prefix='/api')
app.register_blueprint(chat_bp, url_prefix='/api')

# uncomment if you need to use database
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Import all models
from src.models.file_model import db as file_db, FileRecord, SearchIndex, SystemConfig

# Initialize database with all models
file_db.init_app(app)
with app.app_context():
    file_db.create_all()

# Initialize services
from src.services.file_watcher import FileWatcherService
from src.services.notification_service import NotificationService

# Start background services
file_watcher = FileWatcherService()
notification_service = NotificationService()

@app.before_first_request
def initialize_services():
    """Initialize background services"""
    try:
        notification_service.start()
        file_watcher.start()
        notification_service.send_system_notification("AI Data Analyzer started successfully")
    except Exception as e:
        print(f"Error starting services: {e}")

@app.teardown_appcontext
def cleanup_services(error):
    """Cleanup services on app shutdown"""
    try:
        if file_watcher:
            file_watcher.stop()
        if notification_service:
            notification_service.stop()
    except Exception as e:
        print(f"Error during cleanup: {e}")

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
            return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
