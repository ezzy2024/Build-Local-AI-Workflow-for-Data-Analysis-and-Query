from src.models.file_model import db, FileRecord, SearchIndex
from whoosh import index
from whoosh.fields import Schema, TEXT, ID, DATETIME
from whoosh.qparser import QueryParser
from whoosh.query import And, Or, Term
import os
import logging
from datetime import datetime, timedelta
from collections import Counter
import json

logger = logging.getLogger(__name__)

class SearchService:
    """Service for searching and indexing file content"""
    
    def __init__(self):
        self.index_dir = os.path.join(os.path.dirname(__file__), '..', 'search_index')
        self.setup_search_index()
        
    def setup_search_index(self):
        """Initialize Whoosh search index"""
        try:
            if not os.path.exists(self.index_dir):
                os.makedirs(self.index_dir)
            
            # Define schema for search index
            schema = Schema(
                file_id=ID(stored=True),
                filename=TEXT(stored=True),
                filepath=TEXT(stored=True),
                file_type=TEXT(stored=True),
                content=TEXT(stored=True),
                tags=TEXT(stored=True),
                created_at=DATETIME(stored=True),
                modified_at=DATETIME(stored=True)
            )
            
            # Create or open index
            index_path = os.path.join(self.index_dir, 'main_index')
            if not os.path.exists(index_path):
                self.index = index.create_index(schema, index_path)
                logger.info("Created new search index")
            else:
                self.index = index.open_dir(index_path)
                logger.info("Opened existing search index")
                
        except Exception as e:
            logger.error(f"Error setting up search index: {e}")
            self.index = None
            
    def rebuild_index(self):
        """Rebuild the entire search index from database"""
        try:
            if not self.index:
                return False
                
            writer = self.index.writer()
            writer.delete_all()  # Clear existing index
            
            # Add all files from database to index
            files = FileRecord.query.all()
            
            for file_record in files:
                self.add_to_index(file_record, writer=writer)
                
            writer.commit()
            logger.info(f"Rebuilt search index with {len(files)} files")
            return True
            
        except Exception as e:
            logger.error(f"Error rebuilding search index: {e}")
            return False
            
    def add_to_index(self, file_record, writer=None):
        """Add file to search index"""
        try:
            if not self.index:
                return False
                
            should_commit = writer is None
            if writer is None:
                writer = self.index.writer()
            
            # Prepare content for indexing
            content_parts = []
            
            if file_record.extracted_text:
                content_parts.append(file_record.extracted_text)
                
            if file_record.analysis_results:
                try:
                    analysis = json.loads(file_record.analysis_results)
                    if isinstance(analysis, dict):
                        # Add analysis text to content
                        for key, value in analysis.items():
                            if isinstance(value, str):
                                content_parts.append(value)
                            elif isinstance(value, list):
                                content_parts.extend([str(v) for v in value if isinstance(v, str)])
                except:
                    pass
            
            content = ' '.join(content_parts)
            tags = file_record.tags or ''
            
            # Add document to index
            writer.add_document(
                file_id=str(file_record.id),
                filename=file_record.filename,
                filepath=file_record.filepath,
                file_type=file_record.file_type,
                content=content,
                tags=tags,
                created_at=file_record.created_at,
                modified_at=file_record.modified_at
            )
            
            if should_commit:
                writer.commit()
                
            return True
            
        except Exception as e:
            logger.error(f"Error adding file {file_record.id} to search index: {e}")
            return False
            
    def remove_from_index(self, file_id):
        """Remove file from search index"""
        try:
            if not self.index:
                return False
                
            writer = self.index.writer()
            writer.delete_by_term('file_id', str(file_id))
            writer.commit()
            
            return True
            
        except Exception as e:
            logger.error(f"Error removing file {file_id} from search index: {e}")
            return False
            
    def search(self, query_text, file_types=None, limit=10):
        """Search through indexed content"""
        try:
            if not self.index or not query_text:
                return []
                
            searcher = self.index.searcher()
            
            # Parse query
            parser = QueryParser("content", self.index.schema)
            query = parser.parse(query_text)
            
            # Add file type filter if specified
            if file_types:
                type_queries = [Term("file_type", ft) for ft in file_types]
                type_query = Or(type_queries)
                query = And([query, type_query])
            
            # Perform search
            results = searcher.search(query, limit=limit)
            
            search_results = []
            for result in results:
                file_id = int(result['file_id'])
                file_record = FileRecord.query.get(file_id)
                
                if file_record:
                    search_results.append({
                        'file': file_record.to_dict(),
                        'score': result.score,
                        'highlights': result.highlights("content") if hasattr(result, 'highlights') else ""
                    })
            
            searcher.close()
            return search_results
            
        except Exception as e:
            logger.error(f"Error searching: {e}")
            return []
            
    def find_similar(self, file_record, limit=5):
        """Find files similar to the given file"""
        try:
            if not file_record.extracted_text:
                return []
            
            # Use key terms from the file's content for similarity search
            key_terms = self.extract_key_terms(file_record.extracted_text)
            
            if not key_terms:
                return []
            
            # Search for files containing similar terms
            query_text = ' OR '.join(key_terms[:10])  # Use top 10 key terms
            results = self.search(query_text, limit=limit + 1)  # +1 to exclude self
            
            # Filter out the original file and return similar files
            similar_files = []
            for result in results:
                if result['file']['id'] != file_record.id:
                    similar_files.append(FileRecord.query.get(result['file']['id']))
                    
            return similar_files[:limit]
            
        except Exception as e:
            logger.error(f"Error finding similar files: {e}")
            return []
            
    def extract_key_terms(self, text, max_terms=20):
        """Extract key terms from text for similarity matching"""
        try:
            if not text:
                return []
            
            # Simple term extraction based on word frequency
            words = text.lower().split()
            
            # Filter out common stop words and short words
            stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'must', 'can', 'this', 'that', 'these', 'those'}
            
            filtered_words = []
            for word in words:
                word = word.strip('.,!?";()[]{}')
                if len(word) > 3 and word not in stop_words and word.isalpha():
                    filtered_words.append(word)
            
            # Count word frequencies
            word_freq = Counter(filtered_words)
            
            # Return most frequent terms
            key_terms = [word for word, freq in word_freq.most_common(max_terms)]
            return key_terms
            
        except Exception as e:
            logger.error(f"Error extracting key terms: {e}")
            return []
            
    def get_content_trends(self, days=30):
        """Get content trends and patterns"""
        try:
            end_date = datetime.utcnow()
            start_date = end_date - timedelta(days=days)
            
            # Get files created/modified in the specified period
            files = FileRecord.query.filter(
                FileRecord.modified_at >= start_date
            ).all()
            
            trends = {
                'total_files': len(files),
                'file_types': {},
                'top_tags': {},
                'activity_by_day': {},
                'file_size_distribution': {
                    'small': 0,    # < 1MB
                    'medium': 0,   # 1MB - 10MB
                    'large': 0     # > 10MB
                }
            }
            
            # Analyze file types
            for file_record in files:
                file_type = file_record.file_type
                trends['file_types'][file_type] = trends['file_types'].get(file_type, 0) + 1
                
                # Analyze tags
                if file_record.tags:
                    tags = file_record.tags.split(',')
                    for tag in tags:
                        tag = tag.strip()
                        if tag:
                            trends['top_tags'][tag] = trends['top_tags'].get(tag, 0) + 1
                
                # Analyze file sizes
                size_mb = file_record.file_size / (1024 * 1024)
                if size_mb < 1:
                    trends['file_size_distribution']['small'] += 1
                elif size_mb < 10:
                    trends['file_size_distribution']['medium'] += 1
                else:
                    trends['file_size_distribution']['large'] += 1
                
                # Activity by day
                day_key = file_record.modified_at.strftime('%Y-%m-%d')
                trends['activity_by_day'][day_key] = trends['activity_by_day'].get(day_key, 0) + 1
            
            # Sort top tags by frequency
            trends['top_tags'] = dict(sorted(trends['top_tags'].items(), key=lambda x: x[1], reverse=True)[:20])
            
            return trends
            
        except Exception as e:
            logger.error(f"Error getting content trends: {e}")
            return {}
            
    def suggest_queries(self, partial_query, limit=5):
        """Suggest query completions based on indexed content"""
        try:
            if not self.index or not partial_query:
                return []
                
            # This is a simplified implementation
            # In a production system, you might want to maintain a separate suggestions index
            
            searcher = self.index.searcher()
            
            # Search for partial matches in content
            parser = QueryParser("content", self.index.schema)
            query = parser.parse(f"{partial_query}*")
            
            results = searcher.search(query, limit=limit * 2)
            
            suggestions = set()
            for result in results:
                content = result.get('content', '')
                words = content.lower().split()
                
                for word in words:
                    if word.startswith(partial_query.lower()) and len(word) > len(partial_query):
                        suggestions.add(word)
                        if len(suggestions) >= limit:
                            break
                            
                if len(suggestions) >= limit:
                    break
            
            searcher.close()
            return list(suggestions)
            
        except Exception as e:
            logger.error(f"Error suggesting queries: {e}")
            return []

