from flask import Blueprint, request, jsonify
from src.models.file_model import db, FileRecord, SearchIndex
from src.services.file_watcher import FileWatcherService
from src.services.file_processor import FileProcessor
import os
import json
from datetime import datetime

files_bp = Blueprint('files', __name__)

@files_bp.route('/files', methods=['GET'])
def get_files():
    """Get all files with optional filtering"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        file_type = request.args.get('type')
        search_query = request.args.get('search')
        
        query = FileRecord.query
        
        if file_type:
            query = query.filter(FileRecord.file_type == file_type)
            
        if search_query:
            query = query.filter(
                db.or_(
                    FileRecord.filename.contains(search_query),
                    FileRecord.extracted_text.contains(search_query),
                    FileRecord.tags.contains(search_query)
                )
            )
        
        files = query.order_by(FileRecord.modified_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'files': [file.to_dict() for file in files.items],
            'total': files.total,
            'pages': files.pages,
            'current_page': page
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@files_bp.route('/files/<int:file_id>', methods=['GET'])
def get_file(file_id):
    """Get specific file details"""
    try:
        file_record = FileRecord.query.get_or_404(file_id)
        return jsonify(file_record.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@files_bp.route('/files/scan', methods=['POST'])
def scan_directory():
    """Manually trigger directory scan"""
    try:
        data = request.get_json()
        directory = data.get('directory')
        
        if not directory or not os.path.exists(directory):
            return jsonify({'error': 'Invalid directory path'}), 400
        
        file_processor = FileProcessor()
        scanned_files = file_processor.scan_directory(directory)
        
        return jsonify({
            'message': f'Scanned {len(scanned_files)} files',
            'files': scanned_files
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@files_bp.route('/files/<int:file_id>/analyze', methods=['POST'])
def analyze_file(file_id):
    """Manually trigger file analysis"""
    try:
        file_record = FileRecord.query.get_or_404(file_id)
        
        file_processor = FileProcessor()
        result = file_processor.analyze_file(file_record.filepath)
        
        if result:
            file_record.extracted_text = result.get('text', '')
            file_record.analysis_results = json.dumps(result.get('analysis', {}))
            file_record.tags = ','.join(result.get('tags', []))
            file_record.last_analyzed = datetime.utcnow()
            db.session.commit()
            
            return jsonify({
                'message': 'File analyzed successfully',
                'results': result
            })
        else:
            return jsonify({'error': 'Analysis failed'}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@files_bp.route('/files/stats', methods=['GET'])
def get_file_stats():
    """Get file statistics"""
    try:
        total_files = FileRecord.query.count()
        document_count = FileRecord.query.filter(FileRecord.file_type == 'document').count()
        image_count = FileRecord.query.filter(FileRecord.file_type == 'image').count()
        video_count = FileRecord.query.filter(FileRecord.file_type == 'video').count()
        analyzed_count = FileRecord.query.filter(FileRecord.last_analyzed.isnot(None)).count()
        
        return jsonify({
            'total_files': total_files,
            'document_count': document_count,
            'image_count': image_count,
            'video_count': video_count,
            'analyzed_count': analyzed_count,
            'analysis_percentage': (analyzed_count / total_files * 100) if total_files > 0 else 0
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@files_bp.route('/files/watched-directories', methods=['GET'])
def get_watched_directories():
    """Get list of watched directories"""
    try:
        watcher = FileWatcherService()
        directories = watcher.get_watched_directories()
        return jsonify({'directories': directories})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@files_bp.route('/files/watched-directories', methods=['POST'])
def add_watched_directory():
    """Add directory to watch list"""
    try:
        data = request.get_json()
        directory = data.get('directory')
        
        if not directory or not os.path.exists(directory):
            return jsonify({'error': 'Invalid directory path'}), 400
        
        watcher = FileWatcherService()
        success = watcher.add_directory(directory)
        
        if success:
            return jsonify({'message': f'Directory {directory} added to watch list'})
        else:
            return jsonify({'error': 'Failed to add directory'}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@files_bp.route('/files/watched-directories/<path:directory>', methods=['DELETE'])
def remove_watched_directory(directory):
    """Remove directory from watch list"""
    try:
        watcher = FileWatcherService()
        success = watcher.remove_directory(directory)
        
        if success:
            return jsonify({'message': f'Directory {directory} removed from watch list'})
        else:
            return jsonify({'error': 'Failed to remove directory'}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

