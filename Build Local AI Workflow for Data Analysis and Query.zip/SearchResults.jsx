import { useState, useEffect } from 'react'
import { 
  Search, 
  Filter, 
  FileText, 
  Image, 
  Video, 
  Clock,
  Star,
  Eye,
  Download
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { toast } from 'sonner'

const SearchResults = () => {
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const [selectedFileTypes, setSelectedFileTypes] = useState([])
  const [recentSearches, setRecentSearches] = useState([])

  useEffect(() => {
    // Load recent searches from localStorage
    const saved = localStorage.getItem('recentSearches')
    if (saved) {
      setRecentSearches(JSON.parse(saved))
    }
  }, [])

  const handleSearch = async () => {
    if (!searchQuery.trim()) return

    setIsLoading(true)
    try {
      const response = await fetch('/api/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          query: searchQuery,
          file_types: selectedFileTypes,
          limit: 20
        })
      })

      if (response.ok) {
        const data = await response.json()
        setSearchResults(data.results || [])
        
        // Add to recent searches
        const newRecentSearches = [
          searchQuery,
          ...recentSearches.filter(s => s !== searchQuery)
        ].slice(0, 5)
        
        setRecentSearches(newRecentSearches)
        localStorage.setItem('recentSearches', JSON.stringify(newRecentSearches))
        
        if (data.results.length === 0) {
          toast.info('No results found for your search')
        }
      } else {
        toast.error('Search failed')
      }
    } catch (error) {
      console.error('Search error:', error)
      toast.error('Search failed')
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSearch()
    }
  }

  const handleRecentSearchClick = (query) => {
    setSearchQuery(query)
  }

  const getFileTypeIcon = (fileType) => {
    switch (fileType) {
      case 'document':
        return <FileText className="w-5 h-5 text-blue-600" />
      case 'image':
        return <Image className="w-5 h-5 text-green-600" />
      case 'video':
        return <Video className="w-5 h-5 text-purple-600" />
      default:
        return <FileText className="w-5 h-5 text-gray-600" />
    }
  }

  const formatFileSize = (bytes) => {
    if (!bytes) return 'Unknown'
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(1024))
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i]
  }

  const highlightText = (text, query) => {
    if (!query || !text) return text
    
    const regex = new RegExp(`(${query})`, 'gi')
    const parts = text.split(regex)
    
    return parts.map((part, index) => 
      regex.test(part) ? (
        <mark key={index} className="bg-yellow-200 dark:bg-yellow-800 px-1 rounded">
          {part}
        </mark>
      ) : part
    )
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Search</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Find content across all your analyzed files
        </p>
      </div>

      {/* Search Bar */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  placeholder="Search for content, keywords, or file names..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="pl-12 text-lg h-12"
                />
              </div>
            </div>
            
            <Select value={selectedFileTypes.join(',')} onValueChange={(value) => setSelectedFileTypes(value ? value.split(',') : [])}>
              <SelectTrigger className="w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="All file types" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All file types</SelectItem>
                <SelectItem value="document">Documents only</SelectItem>
                <SelectItem value="image">Images only</SelectItem>
                <SelectItem value="video">Videos only</SelectItem>
              </SelectContent>
            </Select>
            
            <Button 
              onClick={handleSearch} 
              disabled={isLoading || !searchQuery.trim()}
              className="px-8"
            >
              {isLoading ? 'Searching...' : 'Search'}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Results */}
        <div className="lg:col-span-3">
          {searchResults.length > 0 ? (
            <Card>
              <CardHeader>
                <CardTitle>Search Results ({searchResults.length})</CardTitle>
                <CardDescription>
                  Results for "{searchQuery}"
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {searchResults.map((result, index) => (
                    <div key={index} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-3 flex-1">
                          {getFileTypeIcon(result.file.file_type)}
                          
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium text-lg mb-1">
                              {highlightText(result.file.filename, searchQuery)}
                            </h3>
                            
                            <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-2">
                              <Badge variant="outline" className="capitalize">
                                {result.file.file_type}
                              </Badge>
                              <span>{formatFileSize(result.file.file_size)}</span>
                              <span>{new Date(result.file.modified_at).toLocaleDateString()}</span>
                            </div>
                            
                            {result.highlights && (
                              <div className="text-sm text-gray-600 dark:text-gray-300 mb-2">
                                <p className="line-clamp-3">
                                  ...{highlightText(result.highlights, searchQuery)}...
                                </p>
                              </div>
                            )}
                            
                            {result.file.extracted_text && (
                              <div className="text-sm text-gray-600 dark:text-gray-300">
                                <p className="line-clamp-2">
                                  {highlightText(result.file.extracted_text.substring(0, 200), searchQuery)}
                                  {result.file.extracted_text.length > 200 && '...'}
                                </p>
                              </div>
                            )}
                            
                            {result.file.tags && result.file.tags.length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-2">
                                {result.file.tags.slice(0, 5).map((tag, tagIndex) => (
                                  <Badge key={tagIndex} variant="secondary" className="text-xs">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2 ml-4">
                          <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                            <Star className="w-4 h-4" />
                            <span>{(result.score * 100).toFixed(0)}%</span>
                          </div>
                          
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ) : searchQuery && !isLoading ? (
            <Card>
              <CardContent className="text-center py-12">
                <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium text-muted-foreground mb-2">No results found</h3>
                <p className="text-muted-foreground">
                  Try different keywords or check your spelling
                </p>
              </CardContent>
            </Card>
          ) : !searchQuery ? (
            <Card>
              <CardContent className="text-center py-12">
                <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium text-muted-foreground mb-2">Start searching</h3>
                <p className="text-muted-foreground">
                  Enter keywords to search through your analyzed files
                </p>
              </CardContent>
            </Card>
          ) : null}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Recent Searches */}
          {recentSearches.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Clock className="w-5 h-5" />
                  <span>Recent Searches</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {recentSearches.map((query, index) => (
                    <Button
                      key={index}
                      variant="ghost"
                      className="w-full justify-start text-left h-auto p-2"
                      onClick={() => handleRecentSearchClick(query)}
                    >
                      <Search className="w-4 h-4 mr-2 text-muted-foreground" />
                      <span className="truncate">{query}</span>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Search Tips */}
          <Card>
            <CardHeader>
              <CardTitle>Search Tips</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div>
                  <h4 className="font-medium mb-1">Exact phrases</h4>
                  <p className="text-muted-foreground">Use quotes: "machine learning"</p>
                </div>
                
                <div>
                  <h4 className="font-medium mb-1">Multiple terms</h4>
                  <p className="text-muted-foreground">Use OR: python OR javascript</p>
                </div>
                
                <div>
                  <h4 className="font-medium mb-1">Exclude terms</h4>
                  <p className="text-muted-foreground">Use minus: AI -artificial</p>
                </div>
                
                <div>
                  <h4 className="font-medium mb-1">File types</h4>
                  <p className="text-muted-foreground">Filter by document, image, or video</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default SearchResults

