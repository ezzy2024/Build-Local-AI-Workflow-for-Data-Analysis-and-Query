import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { 
  LayoutDashboard, 
  Files, 
  MessageSquare, 
  Search, 
  Settings, 
  ChevronLeft,
  ChevronRight,
  Database,
  FileText,
  Image,
  Video,
  Brain
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'

const Sidebar = ({ isOpen, onToggle, stats }) => {
  const location = useLocation()

  const menuItems = [
    { path: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/files', icon: Files, label: 'File Manager' },
    { path: '/chat', icon: MessageSquare, label: 'AI Chat' },
    { path: '/search', icon: Search, label: 'Search' },
    { path: '/settings', icon: Settings, label: 'Settings' }
  ]

  const isActive = (path) => location.pathname === path

  return (
    <div className={`fixed left-0 top-0 h-full bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 transition-all duration-300 z-50 ${isOpen ? 'w-64' : 'w-16'}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
        <div className={`flex items-center space-x-3 ${isOpen ? 'opacity-100' : 'opacity-0'} transition-opacity duration-300`}>
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
            <Brain className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-gray-900 dark:text-white">AI Data Analyzer</h1>
            <p className="text-xs text-gray-500 dark:text-gray-400">Local Analysis System</p>
          </div>
        </div>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggle}
          className="p-2"
        >
          {isOpen ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </Button>
      </div>

      {/* Stats Overview */}
      {isOpen && (
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Database className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-600 dark:text-gray-300">Total Files</span>
              </div>
              <Badge variant="secondary">{stats.totalFiles || 0}</Badge>
            </div>
            
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className="flex flex-col items-center p-2 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <FileText className="w-4 h-4 text-blue-600 dark:text-blue-400 mb-1" />
                <span className="text-blue-600 dark:text-blue-400 font-medium">{stats.documentCount || 0}</span>
                <span className="text-gray-500 dark:text-gray-400">Docs</span>
              </div>
              
              <div className="flex flex-col items-center p-2 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <Image className="w-4 h-4 text-green-600 dark:text-green-400 mb-1" />
                <span className="text-green-600 dark:text-green-400 font-medium">{stats.imageCount || 0}</span>
                <span className="text-gray-500 dark:text-gray-400">Images</span>
              </div>
              
              <div className="flex flex-col items-center p-2 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                <Video className="w-4 h-4 text-purple-600 dark:text-purple-400 mb-1" />
                <span className="text-purple-600 dark:text-purple-400 font-medium">{stats.videoCount || 0}</span>
                <span className="text-gray-500 dark:text-gray-400">Videos</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-500 dark:text-gray-400">Analyzed</span>
              <div className="flex items-center space-x-2">
                <div className="w-16 h-1.5 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-blue-500 to-purple-600 rounded-full transition-all duration-300"
                    style={{ 
                      width: `${stats.totalFiles > 0 ? (stats.analyzedFiles / stats.totalFiles) * 100 : 0}%` 
                    }}
                  />
                </div>
                <span className="text-gray-600 dark:text-gray-300 font-medium">
                  {stats.totalFiles > 0 ? Math.round((stats.analyzedFiles / stats.totalFiles) * 100) : 0}%
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon
            return (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={`flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-all duration-200 group ${
                    isActive(item.path)
                      ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                      : 'text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-gray-900 dark:hover:text-white'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${isActive(item.path) ? 'text-blue-600 dark:text-blue-400' : 'text-gray-500 group-hover:text-gray-700 dark:group-hover:text-gray-300'}`} />
                  <span className={`font-medium ${isOpen ? 'opacity-100' : 'opacity-0'} transition-opacity duration-300`}>
                    {item.label}
                  </span>
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* Footer */}
      {isOpen && (
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <div className="text-xs text-gray-500 dark:text-gray-400 text-center">
            <p>Local & Secure</p>
            <p>No data leaves your device</p>
          </div>
        </div>
      )}
    </div>
  )
}

export default Sidebar

