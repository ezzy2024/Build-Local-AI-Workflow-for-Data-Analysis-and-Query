import os
import sys
import logging
import json
from datetime import datetime
import subprocess
import tempfile

logger = logging.getLogger(__name__)

class WindowsNotificationService:
    """Windows-specific notification service using native Windows toast notifications"""
    
    def __init__(self):
        self.is_windows = sys.platform.startswith('win')
        self.notification_history = []
        
        if self.is_windows:
            try:
                # Try to import Windows-specific modules
                import win32gui
                import win32con
                self.win32_available = True
                logger.info("Windows notification service initialized")
            except ImportError:
                self.win32_available = False
                logger.warning("win32gui not available, using fallback notifications")
        else:
            self.win32_available = False
            logger.info("Non-Windows system detected, using cross-platform notifications")
    
    def show_notification(self, title, message, notification_type='info', duration=5000):
        """Show a notification popup"""
        try:
            notification_data = {
                'title': title,
                'message': message,
                'type': notification_type,
                'timestamp': datetime.now().isoformat(),
                'duration': duration
            }
            
            self.notification_history.append(notification_data)
            
            if self.is_windows and self.win32_available:
                return self._show_windows_toast(title, message, notification_type, duration)
            else:
                return self._show_cross_platform_notification(title, message, notification_type)
                
        except Exception as e:
            logger.error(f"Error showing notification: {e}")
            return False
    
    def _show_windows_toast(self, title, message, notification_type, duration):
        """Show Windows 10/11 toast notification"""
        try:
            # Create PowerShell script for toast notification
            ps_script = f'''
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$notification = New-Object System.Windows.Forms.NotifyIcon
$notification.Icon = [System.Drawing.SystemIcons]::Information
$notification.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Info
$notification.BalloonTipText = "{message}"
$notification.BalloonTipTitle = "{title}"
$notification.Visible = $true
$notification.ShowBalloonTip({duration})

Start-Sleep -Seconds {duration // 1000}
$notification.Dispose()
'''
            
            # Write script to temporary file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.ps1', delete=False) as f:
                f.write(ps_script)
                script_path = f.name
            
            # Execute PowerShell script
            subprocess.run([
                'powershell.exe', 
                '-ExecutionPolicy', 'Bypass',
                '-File', script_path
            ], capture_output=True, text=True)
            
            # Clean up
            os.unlink(script_path)
            
            logger.info(f"Windows toast notification shown: {title}")
            return True
            
        except Exception as e:
            logger.error(f"Error showing Windows toast: {e}")
            return self._show_cross_platform_notification(title, message, notification_type)
    
    def _show_cross_platform_notification(self, title, message, notification_type):
        """Fallback cross-platform notification"""
        try:
            # Try using plyer for cross-platform notifications
            try:
                from plyer import notification
                notification.notify(
                    title=title,
                    message=message,
                    timeout=5
                )
                logger.info(f"Cross-platform notification shown: {title}")
                return True
            except ImportError:
                pass
            
            # Fallback to system notification commands
            if sys.platform.startswith('win'):
                # Windows fallback using msg command
                subprocess.run([
                    'msg', '*', f"{title}: {message}"
                ], capture_output=True)
                return True
            elif sys.platform == 'darwin':
                # macOS notification
                subprocess.run([
                    'osascript', '-e', 
                    f'display notification "{message}" with title "{title}"'
                ], capture_output=True)
                return True
            elif sys.platform.startswith('linux'):
                # Linux notification using notify-send
                subprocess.run([
                    'notify-send', title, message
                ], capture_output=True)
                return True
            
            # Final fallback - just log
            logger.info(f"Notification: {title} - {message}")
            return True
            
        except Exception as e:
            logger.error(f"Error showing cross-platform notification: {e}")
            return False
    
    def notify_new_files(self, file_count, file_types):
        """Notify about new files detected"""
        if file_count == 1:
            title = "New File Detected"
            message = f"1 new {file_types[0]} file found and queued for analysis"
        else:
            type_summary = ", ".join([f"{count} {ftype}" for ftype, count in file_types.items()])
            title = f"{file_count} New Files Detected"
            message = f"Found {type_summary} files and queued for analysis"
        
        return self.show_notification(title, message, 'info')
    
    def notify_analysis_complete(self, filename, file_type, analysis_results):
        """Notify about completed file analysis"""
        title = "Analysis Complete"
        
        insights = []
        if analysis_results.get('tags'):
            insights.append(f"{len(analysis_results['tags'])} tags")
        if analysis_results.get('entities'):
            insights.append(f"{len(analysis_results['entities'])} entities")
        
        if insights:
            message = f"{filename} analyzed successfully. Found {', '.join(insights)}."
        else:
            message = f"{filename} has been analyzed and indexed."
        
        return self.show_notification(title, message, 'success')
    
    def notify_analysis_error(self, filename, error_message):
        """Notify about analysis errors"""
        title = "Analysis Error"
        message = f"Failed to analyze {filename}: {error_message}"
        
        return self.show_notification(title, message, 'error')
    
    def notify_system_status(self, status, message):
        """Notify about system status changes"""
        title = f"System {status.title()}"
        
        return self.show_notification(title, message, 'warning' if status == 'warning' else 'info')
    
    def notify_search_results(self, query, result_count):
        """Notify about search results"""
        title = "Search Complete"
        
        if result_count == 0:
            message = f"No results found for '{query}'"
        elif result_count == 1:
            message = f"Found 1 result for '{query}'"
        else:
            message = f"Found {result_count} results for '{query}'"
        
        return self.show_notification(title, message, 'info')
    
    def get_notification_history(self, limit=50):
        """Get recent notification history"""
        return self.notification_history[-limit:] if limit else self.notification_history
    
    def clear_notification_history(self):
        """Clear notification history"""
        self.notification_history.clear()
        logger.info("Notification history cleared")
    
    def test_notification(self):
        """Test notification system"""
        return self.show_notification(
            "AI Data Analyzer Test",
            "Notification system is working correctly!",
            'info'
        )

# Global notification service instance
notification_service = WindowsNotificationService()

def show_notification(title, message, notification_type='info', duration=5000):
    """Convenience function for showing notifications"""
    return notification_service.show_notification(title, message, notification_type, duration)

def notify_new_files(file_count, file_types):
    """Convenience function for new file notifications"""
    return notification_service.notify_new_files(file_count, file_types)

def notify_analysis_complete(filename, file_type, analysis_results):
    """Convenience function for analysis complete notifications"""
    return notification_service.notify_analysis_complete(filename, file_type, analysis_results)

def notify_analysis_error(filename, error_message):
    """Convenience function for analysis error notifications"""
    return notification_service.notify_analysis_error(filename, error_message)

def test_notifications():
    """Test the notification system"""
    return notification_service.test_notification()

