import os
import time
import threading
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from src.models.file_model import db, FileRecord, SystemConfig
from src.services.file_processor import FileProcessor
from src.services.notification_service import NotificationService
import json
import logging

logger = logging.getLogger(__name__)

class FileChangeHandler(FileSystemEventHandler):
    """Handler for file system events"""
    
    def __init__(self, file_processor, notification_service):
        self.file_processor = file_processor
        self.notification_service = notification_service
        self.processing_queue = []
        self.processing_lock = threading.Lock()
        
    def on_created(self, event):
        if not event.is_directory:
            logger.info(f"New file detected: {event.src_path}")
            self.queue_for_processing(event.src_path, 'created')
            
    def on_modified(self, event):
        if not event.is_directory:
            logger.info(f"File modified: {event.src_path}")
            self.queue_for_processing(event.src_path, 'modified')
            
    def on_deleted(self, event):
        if not event.is_directory:
            logger.info(f"File deleted: {event.src_path}")
            self.handle_file_deletion(event.src_path)
            
    def queue_for_processing(self, filepath, event_type):
        """Queue file for processing to avoid overwhelming the system"""
        with self.processing_lock:
            # Avoid duplicate processing
            if filepath not in [item['path'] for item in self.processing_queue]:
                self.processing_queue.append({
                    'path': filepath,
                    'event_type': event_type,
                    'timestamp': time.time()
                })
                
    def handle_file_deletion(self, filepath):
        """Handle file deletion from database"""
        try:
            file_record = FileRecord.query.filter_by(filepath=filepath).first()
            if file_record:
                db.session.delete(file_record)
                db.session.commit()
                logger.info(f"Removed deleted file from database: {filepath}")
                
                # Send notification
                self.notification_service.send_notification(
                    "File Deleted",
                    f"File removed from system: {os.path.basename(filepath)}"
                )
        except Exception as e:
            logger.error(f"Error handling file deletion: {e}")
            
    def process_queue(self):
        """Process queued files"""
        while True:
            try:
                with self.processing_lock:
                    if self.processing_queue:
                        item = self.processing_queue.pop(0)
                        filepath = item['path']
                        event_type = item['event_type']
                        
                        # Check if file still exists and is stable (not being written to)
                        if os.path.exists(filepath):
                            # Wait a bit to ensure file is completely written
                            time.sleep(2)
                            
                            if os.path.exists(filepath):  # Check again
                                try:
                                    result = self.file_processor.process_file(filepath)
                                    if result:
                                        self.notification_service.send_notification(
                                            "File Processed",
                                            f"Successfully analyzed: {os.path.basename(filepath)}"
                                        )
                                    else:
                                        logger.warning(f"Failed to process file: {filepath}")
                                except Exception as e:
                                    logger.error(f"Error processing file {filepath}: {e}")
                
                time.sleep(1)  # Check queue every second
            except Exception as e:
                logger.error(f"Error in process_queue: {e}")
                time.sleep(5)  # Wait longer on error

class FileWatcherService:
    """Service for watching file system changes"""
    
    def __init__(self):
        self.observer = Observer()
        self.watched_directories = []
        self.file_processor = FileProcessor()
        self.notification_service = NotificationService()
        self.handler = FileChangeHandler(self.file_processor, self.notification_service)
        self.is_running = False
        
        # Start the processing thread
        self.processing_thread = threading.Thread(target=self.handler.process_queue, daemon=True)
        self.processing_thread.start()
        
    def start(self):
        """Start the file watcher"""
        try:
            if not self.is_running:
                self.load_watched_directories()
                self.observer.start()
                self.is_running = True
                logger.info("File watcher started")
                return True
        except Exception as e:
            logger.error(f"Failed to start file watcher: {e}")
            return False
            
    def stop(self):
        """Stop the file watcher"""
        try:
            if self.is_running:
                self.observer.stop()
                self.observer.join()
                self.is_running = False
                logger.info("File watcher stopped")
                return True
        except Exception as e:
            logger.error(f"Failed to stop file watcher: {e}")
            return False
            
    def add_directory(self, directory_path):
        """Add directory to watch list"""
        try:
            if os.path.exists(directory_path) and os.path.isdir(directory_path):
                # Add to observer
                self.observer.schedule(self.handler, directory_path, recursive=True)
                
                # Add to watched directories list
                if directory_path not in self.watched_directories:
                    self.watched_directories.append(directory_path)
                    self.save_watched_directories()
                    
                logger.info(f"Added directory to watch list: {directory_path}")
                
                # Perform initial scan
                self.file_processor.scan_directory(directory_path)
                
                return True
            else:
                logger.error(f"Directory does not exist: {directory_path}")
                return False
        except Exception as e:
            logger.error(f"Failed to add directory {directory_path}: {e}")
            return False
            
    def remove_directory(self, directory_path):
        """Remove directory from watch list"""
        try:
            if directory_path in self.watched_directories:
                self.watched_directories.remove(directory_path)
                self.save_watched_directories()
                
                # Restart observer to apply changes
                if self.is_running:
                    self.stop()
                    time.sleep(1)
                    self.start()
                    
                logger.info(f"Removed directory from watch list: {directory_path}")
                return True
            else:
                logger.warning(f"Directory not in watch list: {directory_path}")
                return False
        except Exception as e:
            logger.error(f"Failed to remove directory {directory_path}: {e}")
            return False
            
    def get_watched_directories(self):
        """Get list of currently watched directories"""
        return self.watched_directories.copy()
        
    def save_watched_directories(self):
        """Save watched directories to database"""
        try:
            config = SystemConfig.query.filter_by(key='watched_directories').first()
            if config:
                config.value = json.dumps(self.watched_directories)
            else:
                config = SystemConfig(
                    key='watched_directories',
                    value=json.dumps(self.watched_directories)
                )
                db.session.add(config)
            db.session.commit()
        except Exception as e:
            logger.error(f"Failed to save watched directories: {e}")
            
    def load_watched_directories(self):
        """Load watched directories from database"""
        try:
            config = SystemConfig.query.filter_by(key='watched_directories').first()
            if config:
                self.watched_directories = json.loads(config.value)
                
                # Add all directories to observer
                for directory in self.watched_directories:
                    if os.path.exists(directory):
                        self.observer.schedule(self.handler, directory, recursive=True)
                    else:
                        logger.warning(f"Watched directory no longer exists: {directory}")
                        
            logger.info(f"Loaded {len(self.watched_directories)} watched directories")
        except Exception as e:
            logger.error(f"Failed to load watched directories: {e}")
            self.watched_directories = []

