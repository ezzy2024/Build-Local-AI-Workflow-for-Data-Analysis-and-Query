# AI Data Analyzer - Complete User Guide

## Table of Contents
1. [Getting Started](#getting-started)
2. [Dashboard Overview](#dashboard-overview)
3. [File Management](#file-management)
4. [AI Chat Interface](#ai-chat-interface)
5. [Search and Discovery](#search-and-discovery)
6. [Settings and Configuration](#settings-and-configuration)
7. [Notifications](#notifications)
8. [Advanced Features](#advanced-features)
9. [Troubleshooting](#troubleshooting)

## Getting Started

### First Launch
After installation, you'll have two desktop shortcuts:
- **AI Data Analyzer**: Starts the backend service
- **AI Data Analyzer - Web Interface**: Opens the web interface

Always start the backend service first, then open the web interface.

### Initial Setup Wizard
On first launch, the system will guide you through:

1. **Welcome Screen**: Overview of features and capabilities
2. **Directory Selection**: Choose folders to monitor for files
3. **AI Configuration**: Optional setup of external AI features
4. **Notification Preferences**: Configure popup notifications
5. **Privacy Settings**: Review and confirm privacy options

### Understanding the Interface
The web interface consists of five main sections:
- **Dashboard**: System overview and statistics
- **File Manager**: Browse and manage your files
- **AI Chat**: Conversational interface for queries
- **Search**: Advanced search capabilities
- **Settings**: System configuration and preferences

## Dashboard Overview

### System Statistics
The dashboard displays real-time information about your system:

**File Counts**
- Total files in the system
- Breakdown by type (documents, images, videos)
- Recently added files

**Analysis Progress**
- Files currently being processed
- Processing queue status
- Completion percentage

**System Health**
- Service status indicators
- Performance metrics
- Error notifications

### Quick Actions
The dashboard provides shortcuts for common tasks:
- **Add Directory**: Start monitoring a new folder
- **Search Files**: Quick access to search functionality
- **AI Chat**: Jump to conversational interface
- **Refresh**: Update all statistics and status

### Recent Activity
View the latest system activity:
- Newly processed files
- Analysis completions
- System events and notifications
- Error reports

## File Management

### Automatic File Detection
The system continuously monitors your selected directories for:
- New files added
- Modified files
- Moved or renamed files
- Deleted files

### Supported File Types

**Documents**
- PDF files (.pdf)
- Microsoft Word (.doc, .docx)
- Text files (.txt, .md, .rtf)
- OpenDocument (.odt)
- PowerPoint presentations (.ppt, .pptx)

**Images**
- JPEG/JPG (.jpg, .jpeg)
- PNG (.png)
- GIF (.gif)
- BMP (.bmp)
- TIFF (.tiff)

**Videos**
- MP4 (.mp4)
- AVI (.avi)
- MOV (.mov)
- WMV (.wmv)
- MKV (.mkv)

### File Processing Pipeline
When a file is detected, it goes through several stages:

1. **Detection**: File system watcher identifies the file
2. **Validation**: Check file type and size limits
3. **Queuing**: Add to processing queue
4. **Analysis**: Extract content and metadata
5. **AI Processing**: Generate insights and tags
6. **Indexing**: Add to searchable database
7. **Notification**: Alert user of completion

### Manual File Upload
You can also manually add files:
1. Go to File Manager
2. Click "Upload Files" or drag and drop
3. Select files from your computer
4. Files will be processed automatically

### File Details View
Click on any file to see detailed information:
- **Basic Info**: Name, size, type, creation date
- **Content Preview**: Text content or image thumbnail
- **AI Analysis**: Generated tags, entities, summary
- **Metadata**: Technical details and properties
- **Processing History**: Analysis timeline and results

### Bulk Operations
Select multiple files to perform batch operations:
- **Re-analyze**: Force reprocessing of selected files
- **Export**: Download files or analysis results
- **Delete**: Remove files from the system
- **Tag**: Add custom tags to multiple files

## AI Chat Interface

### Starting a Conversation
The AI Chat interface allows natural language interaction with your files:

1. Type your question in the chat input
2. Press Enter or click Send
3. The AI will search your files and provide answers
4. Continue the conversation with follow-up questions

### Types of Queries

**File Discovery**
- "What files do I have about machine learning?"
- "Show me documents created last week"
- "Find images with people in them"
- "List all PDF files larger than 5MB"

**Content Analysis**
- "Summarize my meeting notes from yesterday"
- "What are the main topics in my research papers?"
- "Find files mentioning budget or financial data"
- "Show me images taken at the beach"

**Comparative Analysis**
- "Compare the content of these two documents"
- "What's different between version 1 and version 2?"
- "Find similar images in my collection"
- "Group files by topic or theme"

**Insights and Trends**
- "What topics do I write about most?"
- "Show me my productivity patterns"
- "What file types do I use most often?"
- "When am I most active in creating content?"

### External AI Mode
Toggle the "External AI" switch to enable enhanced capabilities:

**Local Mode (Default)**
- Uses only your local files and data
- Completely private and secure
- Limited to information in your files

**External AI Mode**
- Combines local data with external knowledge
- Can answer general questions and provide context
- Privacy filters prevent sensitive data from leaving your system
- Requires OpenAI API key

### Conversation Features

**Context Awareness**
- The AI remembers previous questions in the conversation
- Reference earlier results: "Tell me more about that document"
- Build on previous queries: "Now find similar files"

**Rich Responses**
- Text summaries and explanations
- File lists with clickable links
- Image previews and thumbnails
- Structured data in tables

**Export Options**
- Save conversations as text files
- Export search results to CSV
- Download referenced files
- Share insights with others

## Search and Discovery

### Basic Search
Use the search bar to find files by:
- **Filename**: Search for specific file names
- **Content**: Full-text search across all file content
- **Tags**: Find files with specific AI-generated tags
- **Metadata**: Search by file properties

### Advanced Search Filters

**File Type Filters**
- Documents only
- Images only
- Videos only
- Specific formats (PDF, DOCX, etc.)

**Date Filters**
- Created date range
- Modified date range
- Last accessed date
- Custom date ranges

**Size Filters**
- File size ranges
- Larger than X MB
- Smaller than X MB
- Empty files

**Content Filters**
- Contains specific text
- Language detection
- Sentiment analysis
- Topic categories

### Search Results
Results are displayed with:
- **Relevance Score**: How well the file matches your query
- **Preview**: Content snippet showing the match
- **Metadata**: File details and properties
- **Quick Actions**: View, analyze, or download options

### Saved Searches
Create and manage saved searches:
1. Perform a search with your desired criteria
2. Click "Save Search" 
3. Give it a descriptive name
4. Access from the "Saved Searches" menu
5. Set up notifications for new matching files

### Smart Suggestions
The system provides intelligent search suggestions:
- **Auto-complete**: Suggests terms as you type
- **Related Searches**: Shows similar queries
- **Popular Searches**: Most common search terms
- **Recent Searches**: Your search history

## Settings and Configuration

### General Settings

**System Preferences**
- Language selection
- Theme (light/dark mode)
- Startup behavior
- Update preferences

**Performance Settings**
- Maximum concurrent file processing
- Memory usage limits
- CPU usage limits
- Cache size configuration

### Watched Directories
Manage folders that the system monitors:

**Adding Directories**
1. Click "Add Directory"
2. Browse and select folder
3. Choose monitoring options:
   - Include subdirectories
   - File type filters
   - Size limits
   - Exclusion patterns

**Directory Options**
- **Real-time Monitoring**: Process files immediately
- **Scheduled Scanning**: Check for changes periodically
- **Manual Processing**: Process only on demand
- **Backup Integration**: Sync with backup systems

### AI Configuration

**Local AI Settings**
- Model selection and configuration
- Processing quality vs. speed
- Language models and preferences
- Custom model integration

**External AI Settings**
- OpenAI API key configuration
- Model selection (GPT-3.5, GPT-4)
- Usage limits and quotas
- Privacy and filtering options

**Analysis Depth**
- **Quick**: Fast processing, basic analysis
- **Standard**: Balanced speed and quality
- **Deep**: Comprehensive analysis, slower processing
- **Custom**: Configure specific analysis modules

### Privacy and Security

**Data Protection**
- Database encryption settings
- File access permissions
- Network security options
- Audit logging configuration

**Privacy Controls**
- Data retention policies
- Automatic data deletion
- Export and backup options
- Third-party data sharing (disabled by default)

**External AI Privacy**
- Privacy filter configuration
- Data sanitization settings
- Audit logs for external queries
- Opt-out options for specific data types

### Notification Settings

**Notification Types**
- New file detection
- Analysis completion
- System errors and warnings
- Search result updates
- System performance alerts

**Delivery Options**
- Windows toast notifications
- Email notifications (optional)
- In-app notifications
- Sound alerts

**Timing and Frequency**
- Immediate notifications
- Batched notifications
- Quiet hours configuration
- Priority-based filtering

## Notifications

### Types of Notifications

**File Processing Notifications**
- "New file detected: document.pdf"
- "Analysis complete: 5 new insights found"
- "Processing error: Unable to read file.docx"

**System Status Notifications**
- "System startup complete"
- "High CPU usage detected"
- "Database backup completed"
- "Update available"

**Search and Discovery Notifications**
- "New files match your saved search 'AI Research'"
- "Similar files found for recent upload"
- "Duplicate files detected"

### Notification Management

**Viewing Notifications**
- Click the notification bell icon
- View notification history
- Mark notifications as read
- Clear all notifications

**Notification Preferences**
- Enable/disable specific notification types
- Set quiet hours (no notifications)
- Configure notification duration
- Choose notification sounds

**Advanced Options**
- Priority-based filtering
- Keyword-based filtering
- Frequency limits (max per hour)
- Integration with Windows Focus Assist

## Advanced Features

### Batch Processing
Process multiple files efficiently:

**Bulk Analysis**
- Select multiple files
- Choose analysis options
- Monitor progress in real-time
- Review results in batch

**Scheduled Processing**
- Set up automatic processing schedules
- Process files during off-hours
- Configure resource limits
- Email reports on completion

### Custom File Processors
Extend the system with custom processors:

**Creating Processors**
1. Create a new Python file in `src/processors/`
2. Inherit from `BaseProcessor`
3. Implement required methods
4. Register the processor

**Example Custom Processor**
```python
class CustomProcessor(BaseProcessor):
    def can_process(self, file_path):
        return file_path.endswith('.custom')
    
    def process(self, file_path):
        # Your processing logic here
        return {
            'content': extracted_content,
            'metadata': metadata_dict,
            'tags': generated_tags
        }
```

### API Integration
Access system functionality programmatically:

**REST API Endpoints**
- File management operations
- Search and query functions
- AI analysis requests
- System status and health

**Python SDK**
```python
from ai_data_analyzer import Client

client = Client('http://localhost:5000')
files = client.search('machine learning')
analysis = client.analyze_file('document.pdf')
```

**Webhook Integration**
- Receive notifications via HTTP callbacks
- Integrate with external systems
- Trigger automated workflows
- Real-time event streaming

### Data Export and Backup

**Export Options**
- Full database export
- Selective file export
- Analysis results only
- Configuration backup

**Backup Strategies**
- Automatic scheduled backups
- Incremental backup support
- Cloud storage integration
- Restore point management

### Performance Monitoring
Monitor system performance and health:

**Real-time Metrics**
- CPU and memory usage
- Processing queue status
- Database performance
- Network activity

**Historical Analysis**
- Performance trends over time
- Processing speed analytics
- Error rate tracking
- Resource usage patterns

**Alerts and Thresholds**
- Configure performance alerts
- Set resource usage limits
- Automatic performance optimization
- Predictive maintenance warnings

## Troubleshooting

### Common Issues and Solutions

**Files Not Processing**
1. Check file permissions
2. Verify file format is supported
3. Check available disk space
4. Review error logs in `logs/` directory

**Slow Performance**
1. Reduce concurrent processing threads
2. Increase available memory
3. Move database to faster storage (SSD)
4. Clear cache and temporary files

**Web Interface Not Loading**
1. Ensure backend service is running
2. Check browser console for errors
3. Try different browser or incognito mode
4. Verify firewall settings

**Notifications Not Working**
1. Check Windows notification settings
2. Verify Focus Assist is not blocking
3. Ensure notification service is enabled
4. Test with simple notification

### Log Analysis
Understanding log files:

**Main Application Log** (`logs/main.log`)
- System startup and shutdown
- Configuration loading
- Service status changes
- General application events

**File Processing Log** (`logs/file_processor.log`)
- File detection events
- Processing start/completion
- Analysis results
- Processing errors

**AI Service Log** (`logs/ai_service.log`)
- AI model loading
- Analysis requests
- External AI calls
- AI processing errors

**Error Log** (`logs/error.log`)
- System errors with stack traces
- Critical failures
- Recovery attempts
- Performance issues

### Performance Optimization

**For Large File Collections**
- Increase processing threads: `max_concurrent_analysis = 6`
- Use SSD storage for database
- Enable GPU acceleration if available
- Increase cache size: `cache_size_mb = 1024`

**For Limited Resources**
- Reduce concurrent processing: `max_concurrent_analysis = 2`
- Limit file size: `max_file_size = 50MB`
- Disable video processing: `process_videos = false`
- Reduce cache: `cache_size_mb = 256`

### Getting Support
If you need additional help:

1. **Check Documentation**: Review this guide and README.md
2. **Search Logs**: Look for error messages in log files
3. **Community Forum**: Ask questions in our user community
4. **Bug Reports**: Submit issues on GitHub with logs and details
5. **Professional Support**: Contact support for enterprise assistance

### System Health Checks
Regular maintenance tasks:

**Weekly Tasks**
- Review system performance metrics
- Clear old log files
- Check for software updates
- Verify backup integrity

**Monthly Tasks**
- Analyze processing trends
- Optimize database performance
- Review and update watched directories
- Clean up temporary files

**Quarterly Tasks**
- Full system backup
- Security audit and updates
- Performance benchmarking
- Configuration review

---

This user guide covers the comprehensive functionality of the AI Data Analyzer system. For additional technical details, refer to the API documentation and developer guides in the `docs/` directory.

