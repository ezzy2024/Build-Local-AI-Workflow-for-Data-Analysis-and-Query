import os
import mimetypes
import hashlib
from datetime import datetime
from src.models.file_model import db, FileRecord, SearchIndex
from src.services.ai_service import AIService
import logging

logger = logging.getLogger(__name__)

class FileProcessor:
    """Service for processing and analyzing files"""
    
    def __init__(self):
        self.ai_service = AIService()
        self.supported_extensions = {
            'document': ['.txt', '.pdf', '.doc', '.docx', '.rtf', '.odt', '.md', '.ppt', '.pptx'],
            'image': ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp', '.svg'],
            'video': ['.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm', '.mkv', '.m4v']
        }
        
    def scan_directory(self, directory_path):
        """Scan directory for supported files"""
        scanned_files = []
        
        try:
            for root, dirs, files in os.walk(directory_path):
                for file in files:
                    filepath = os.path.join(root, file)
                    
                    if self.is_supported_file(filepath):
                        result = self.process_file(filepath)
                        if result:
                            scanned_files.append(result)
                            
        except Exception as e:
            logger.error(f"Error scanning directory {directory_path}: {e}")
            
        logger.info(f"Scanned {len(scanned_files)} files in {directory_path}")
        return scanned_files
        
    def process_file(self, filepath):
        """Process a single file"""
        try:
            if not os.path.exists(filepath):
                logger.warning(f"File does not exist: {filepath}")
                return None
                
            if not self.is_supported_file(filepath):
                logger.debug(f"Unsupported file type: {filepath}")
                return None
                
            # Check if file already exists in database
            existing_file = FileRecord.query.filter_by(filepath=filepath).first()
            
            # Get file stats
            stat = os.stat(filepath)
            modified_time = datetime.fromtimestamp(stat.st_mtime)
            
            # Skip if file hasn't been modified since last analysis
            if existing_file and existing_file.modified_at >= modified_time:
                logger.debug(f"File not modified since last analysis: {filepath}")
                return existing_file.to_dict()
            
            # Determine file type
            file_type = self.get_file_type(filepath)
            file_extension = os.path.splitext(filepath)[1].lower()
            filename = os.path.basename(filepath)
            file_size = stat.st_size
            
            # Create or update file record
            if existing_file:
                file_record = existing_file
                file_record.modified_at = modified_time
            else:
                file_record = FileRecord(
                    filename=filename,
                    filepath=filepath,
                    file_type=file_type,
                    file_extension=file_extension,
                    file_size=file_size,
                    created_at=datetime.fromtimestamp(stat.st_ctime),
                    modified_at=modified_time
                )
                db.session.add(file_record)
            
            # Analyze file content
            analysis_result = self.analyze_file(filepath)
            
            if analysis_result:
                file_record.extracted_text = analysis_result.get('text', '')
                file_record.analysis_results = str(analysis_result.get('analysis', {}))
                file_record.tags = ','.join(analysis_result.get('tags', []))
                file_record.last_analyzed = datetime.utcnow()
                
                # Update search index
                self.update_search_index(file_record, analysis_result)
            
            db.session.commit()
            logger.info(f"Processed file: {filepath}")
            
            return file_record.to_dict()
            
        except Exception as e:
            logger.error(f"Error processing file {filepath}: {e}")
            db.session.rollback()
            return None
            
    def analyze_file(self, filepath):
        """Analyze file content using AI services"""
        try:
            file_type = self.get_file_type(filepath)
            
            if file_type == 'document':
                return self.ai_service.analyze_document(filepath)
            elif file_type == 'image':
                return self.ai_service.analyze_image(filepath)
            elif file_type == 'video':
                return self.ai_service.analyze_video(filepath)
            else:
                logger.warning(f"Unknown file type for analysis: {filepath}")
                return None
                
        except Exception as e:
            logger.error(f"Error analyzing file {filepath}: {e}")
            return None
            
    def is_supported_file(self, filepath):
        """Check if file type is supported"""
        file_extension = os.path.splitext(filepath)[1].lower()
        
        for file_type, extensions in self.supported_extensions.items():
            if file_extension in extensions:
                return True
                
        return False
        
    def get_file_type(self, filepath):
        """Determine file type category"""
        file_extension = os.path.splitext(filepath)[1].lower()
        
        for file_type, extensions in self.supported_extensions.items():
            if file_extension in extensions:
                return file_type
                
        return 'unknown'
        
    def update_search_index(self, file_record, analysis_result):
        """Update search index with file content"""
        try:
            # Remove existing search entries for this file
            SearchIndex.query.filter_by(file_id=file_record.id).delete()
            
            # Add extracted text to search index
            if analysis_result.get('text'):
                search_entry = SearchIndex(
                    file_id=file_record.id,
                    content=analysis_result['text'],
                    content_type='text'
                )
                db.session.add(search_entry)
            
            # Add metadata to search index
            if analysis_result.get('metadata'):
                metadata_text = ' '.join([
                    f"{k}: {v}" for k, v in analysis_result['metadata'].items()
                    if isinstance(v, (str, int, float))
                ])
                if metadata_text:
                    search_entry = SearchIndex(
                        file_id=file_record.id,
                        content=metadata_text,
                        content_type='metadata'
                    )
                    db.session.add(search_entry)
            
            # Add tags to search index
            if analysis_result.get('tags'):
                tags_text = ' '.join(analysis_result['tags'])
                search_entry = SearchIndex(
                    file_id=file_record.id,
                    content=tags_text,
                    content_type='tags'
                )
                db.session.add(search_entry)
                
        except Exception as e:
            logger.error(f"Error updating search index for file {file_record.id}: {e}")
            
    def get_file_hash(self, filepath):
        """Generate hash for file content"""
        try:
            hash_md5 = hashlib.md5()
            with open(filepath, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_md5.update(chunk)
            return hash_md5.hexdigest()
        except Exception as e:
            logger.error(f"Error generating hash for {filepath}: {e}")
            return None
            
    def cleanup_deleted_files(self):
        """Remove records for files that no longer exist"""
        try:
            deleted_count = 0
            all_files = FileRecord.query.all()
            
            for file_record in all_files:
                if not os.path.exists(file_record.filepath):
                    # Remove search index entries
                    SearchIndex.query.filter_by(file_id=file_record.id).delete()
                    
                    # Remove file record
                    db.session.delete(file_record)
                    deleted_count += 1
                    
            db.session.commit()
            logger.info(f"Cleaned up {deleted_count} deleted file records")
            
            return deleted_count
            
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")
            db.session.rollback()
            return 0

