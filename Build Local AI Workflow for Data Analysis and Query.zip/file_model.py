from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class FileRecord(db.Model):
    __tablename__ = 'files'
    
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    filepath = db.Column(db.String(500), nullable=False, unique=True)
    file_type = db.Column(db.String(50), nullable=False)  # document, image, video
    file_extension = db.Column(db.String(10), nullable=False)
    file_size = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    modified_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_analyzed = db.Column(db.DateTime)
    
    # Analysis results
    extracted_text = db.Column(db.Text)
    analysis_results = db.Column(db.Text)  # JSON string
    tags = db.Column(db.String(500))  # Comma-separated tags
    
    def to_dict(self):
        return {
            'id': self.id,
            'filename': self.filename,
            'filepath': self.filepath,
            'file_type': self.file_type,
            'file_extension': self.file_extension,
            'file_size': self.file_size,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'modified_at': self.modified_at.isoformat() if self.modified_at else None,
            'last_analyzed': self.last_analyzed.isoformat() if self.last_analyzed else None,
            'extracted_text': self.extracted_text,
            'analysis_results': json.loads(self.analysis_results) if self.analysis_results else None,
            'tags': self.tags.split(',') if self.tags else []
        }

class SearchIndex(db.Model):
    __tablename__ = 'search_index'
    
    id = db.Column(db.Integer, primary_key=True)
    file_id = db.Column(db.Integer, db.ForeignKey('files.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    content_type = db.Column(db.String(50), nullable=False)  # text, ocr, metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    file = db.relationship('FileRecord', backref=db.backref('search_entries', lazy=True))

class SystemConfig(db.Model):
    __tablename__ = 'system_config'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), nullable=False, unique=True)
    value = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

