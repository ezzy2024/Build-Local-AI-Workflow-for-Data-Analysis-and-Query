import os
import cv2
import pytesseract
from PIL import Image
import spacy
import nltk
from transformers import pipeline, AutoTokenizer, AutoModel
import torch
import whisper
import logging
from datetime import datetime
import json
import fitz  # PyMuPDF for PDF processing
from docx import Document  # python-docx for Word documents
from pptx import Presentation  # python-pptx for PowerPoint

logger = logging.getLogger(__name__)

class AIService:
    """Service for AI-powered content analysis"""
    
    def __init__(self):
        self.setup_models()
        
    def setup_models(self):
        """Initialize AI models"""
        try:
            # Download required NLTK data
            try:
                nltk.data.find('tokenizers/punkt')
            except LookupError:
                nltk.download('punkt')
                
            try:
                nltk.data.find('corpora/stopwords')
            except LookupError:
                nltk.download('stopwords')
            
            # Load spaCy model (download if not available)
            try:
                self.nlp = spacy.load("en_core_web_sm")
            except OSError:
                logger.warning("spaCy model not found. Please install with: python -m spacy download en_core_web_sm")
                self.nlp = None
            
            # Initialize transformers pipelines
            try:
                self.summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
                self.classifier = pipeline("zero-shot-classification", model="facebook/bart-large-mnli")
                self.sentiment_analyzer = pipeline("sentiment-analysis")
            except Exception as e:
                logger.warning(f"Could not initialize some transformers models: {e}")
                self.summarizer = None
                self.classifier = None
                self.sentiment_analyzer = None
            
            # Initialize Whisper for audio transcription
            try:
                self.whisper_model = whisper.load_model("base")
            except Exception as e:
                logger.warning(f"Could not load Whisper model: {e}")
                self.whisper_model = None
                
            logger.info("AI models initialized successfully")
            
        except Exception as e:
            logger.error(f"Error initializing AI models: {e}")
            
    def analyze_document(self, filepath):
        """Analyze document files"""
        try:
            text = self.extract_text_from_document(filepath)
            
            if not text:
                return None
                
            analysis = {
                'text': text,
                'analysis': {},
                'tags': [],
                'metadata': {}
            }
            
            # Perform NLP analysis
            if self.nlp:
                doc = self.nlp(text[:1000000])  # Limit text size for processing
                
                # Extract entities
                entities = [(ent.text, ent.label_) for ent in doc.ents]
                analysis['analysis']['entities'] = entities
                
                # Extract key phrases (noun phrases)
                noun_phrases = [chunk.text for chunk in doc.noun_chunks]
                analysis['analysis']['key_phrases'] = noun_phrases[:20]  # Limit to top 20
            
            # Sentiment analysis
            if self.sentiment_analyzer and len(text) > 0:
                try:
                    sentiment = self.sentiment_analyzer(text[:512])  # Limit for model
                    analysis['analysis']['sentiment'] = sentiment[0]
                except Exception as e:
                    logger.warning(f"Sentiment analysis failed: {e}")
            
            # Generate summary
            if self.summarizer and len(text) > 100:
                try:
                    summary = self.summarizer(text[:1024], max_length=150, min_length=30, do_sample=False)
                    analysis['analysis']['summary'] = summary[0]['summary_text']
                except Exception as e:
                    logger.warning(f"Summarization failed: {e}")
            
            # Generate tags based on content
            analysis['tags'] = self.generate_tags_from_text(text)
            
            # Add metadata
            analysis['metadata'] = {
                'word_count': len(text.split()),
                'character_count': len(text),
                'file_extension': os.path.splitext(filepath)[1],
                'analysis_timestamp': datetime.utcnow().isoformat()
            }
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing document {filepath}: {e}")
            return None
            
    def analyze_image(self, filepath):
        """Analyze image files"""
        try:
            analysis = {
                'text': '',
                'analysis': {},
                'tags': [],
                'metadata': {}
            }
            
            # Load image
            image = cv2.imread(filepath)
            if image is None:
                logger.error(f"Could not load image: {filepath}")
                return None
            
            # Extract text using OCR
            try:
                pil_image = Image.open(filepath)
                ocr_text = pytesseract.image_to_string(pil_image)
                analysis['text'] = ocr_text.strip()
            except Exception as e:
                logger.warning(f"OCR failed for {filepath}: {e}")
            
            # Basic image analysis
            height, width, channels = image.shape
            analysis['metadata'] = {
                'width': width,
                'height': height,
                'channels': channels,
                'file_size': os.path.getsize(filepath),
                'file_extension': os.path.splitext(filepath)[1],
                'analysis_timestamp': datetime.utcnow().isoformat()
            }
            
            # Color analysis
            try:
                # Calculate dominant colors
                pixels = image.reshape((-1, 3))
                pixels = pixels[::100]  # Sample every 100th pixel for performance
                
                # Simple color analysis
                avg_color = pixels.mean(axis=0)
                analysis['analysis']['average_color'] = {
                    'b': int(avg_color[0]),
                    'g': int(avg_color[1]),
                    'r': int(avg_color[2])
                }
                
                # Brightness analysis
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                brightness = gray.mean()
                analysis['analysis']['brightness'] = float(brightness)
                
            except Exception as e:
                logger.warning(f"Color analysis failed for {filepath}: {e}")
            
            # Generate tags
            tags = ['image']
            
            # Add tags based on file extension
            ext = os.path.splitext(filepath)[1].lower()
            if ext in ['.jpg', '.jpeg']:
                tags.append('jpeg')
            elif ext == '.png':
                tags.append('png')
            elif ext == '.gif':
                tags.append('gif')
            
            # Add tags based on OCR text
            if analysis['text']:
                tags.extend(self.generate_tags_from_text(analysis['text']))
            
            analysis['tags'] = tags
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing image {filepath}: {e}")
            return None
            
    def analyze_video(self, filepath):
        """Analyze video files"""
        try:
            analysis = {
                'text': '',
                'analysis': {},
                'tags': [],
                'metadata': {}
            }
            
            # Get video metadata using OpenCV
            cap = cv2.VideoCapture(filepath)
            if not cap.isOpened():
                logger.error(f"Could not open video: {filepath}")
                return None
            
            # Extract metadata
            fps = cap.get(cv2.CAP_PROP_FPS)
            frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            duration = frame_count / fps if fps > 0 else 0
            
            analysis['metadata'] = {
                'duration_seconds': duration,
                'fps': fps,
                'frame_count': frame_count,
                'width': width,
                'height': height,
                'file_size': os.path.getsize(filepath),
                'file_extension': os.path.splitext(filepath)[1],
                'analysis_timestamp': datetime.utcnow().isoformat()
            }
            
            # Extract audio and transcribe if Whisper is available
            if self.whisper_model:
                try:
                    # Use whisper to transcribe audio
                    result = self.whisper_model.transcribe(filepath)
                    analysis['text'] = result['text']
                    analysis['analysis']['transcription_language'] = result.get('language', 'unknown')
                except Exception as e:
                    logger.warning(f"Audio transcription failed for {filepath}: {e}")
            
            # Extract key frames for analysis (sample frames)
            try:
                frame_samples = []
                sample_count = min(5, frame_count // 10)  # Sample up to 5 frames
                
                for i in range(sample_count):
                    frame_pos = (frame_count // sample_count) * i
                    cap.set(cv2.CAP_PROP_POS_FRAMES, frame_pos)
                    ret, frame = cap.read()
                    
                    if ret:
                        # Analyze frame brightness and color
                        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                        brightness = gray.mean()
                        
                        avg_color = frame.reshape((-1, 3)).mean(axis=0)
                        
                        frame_samples.append({
                            'frame_position': frame_pos,
                            'brightness': float(brightness),
                            'avg_color': {
                                'b': int(avg_color[0]),
                                'g': int(avg_color[1]),
                                'r': int(avg_color[2])
                            }
                        })
                
                analysis['analysis']['frame_samples'] = frame_samples
                
            except Exception as e:
                logger.warning(f"Frame analysis failed for {filepath}: {e}")
            
            cap.release()
            
            # Generate tags
            tags = ['video']
            
            # Add tags based on file extension
            ext = os.path.splitext(filepath)[1].lower()
            if ext == '.mp4':
                tags.append('mp4')
            elif ext == '.avi':
                tags.append('avi')
            elif ext == '.mov':
                tags.append('mov')
            
            # Add tags based on transcription
            if analysis['text']:
                tags.extend(self.generate_tags_from_text(analysis['text']))
            
            # Add tags based on duration
            if duration > 0:
                if duration < 60:
                    tags.append('short')
                elif duration < 600:
                    tags.append('medium')
                else:
                    tags.append('long')
            
            analysis['tags'] = tags
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing video {filepath}: {e}")
            return None
            
    def extract_text_from_document(self, filepath):
        """Extract text from various document formats"""
        try:
            ext = os.path.splitext(filepath)[1].lower()
            
            if ext == '.txt':
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    return f.read()
                    
            elif ext == '.pdf':
                text = ""
                try:
                    doc = fitz.open(filepath)
                    for page in doc:
                        text += page.get_text()
                    doc.close()
                    return text
                except Exception as e:
                    logger.warning(f"PDF text extraction failed: {e}")
                    return ""
                    
            elif ext in ['.doc', '.docx']:
                try:
                    doc = Document(filepath)
                    text = ""
                    for paragraph in doc.paragraphs:
                        text += paragraph.text + "\n"
                    return text
                except Exception as e:
                    logger.warning(f"Word document processing failed: {e}")
                    return ""
                    
            elif ext in ['.ppt', '.pptx']:
                try:
                    prs = Presentation(filepath)
                    text = ""
                    for slide in prs.slides:
                        for shape in slide.shapes:
                            if hasattr(shape, "text"):
                                text += shape.text + "\n"
                    return text
                except Exception as e:
                    logger.warning(f"PowerPoint processing failed: {e}")
                    return ""
                    
            elif ext == '.md':
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    return f.read()
                    
            else:
                logger.warning(f"Unsupported document format: {ext}")
                return ""
                
        except Exception as e:
            logger.error(f"Error extracting text from {filepath}: {e}")
            return ""
            
    def generate_tags_from_text(self, text):
        """Generate tags from text content"""
        try:
            tags = []
            
            if not text or len(text.strip()) == 0:
                return tags
            
            # Use spaCy for entity recognition if available
            if self.nlp:
                doc = self.nlp(text[:10000])  # Limit text size
                
                # Extract person names
                persons = [ent.text.lower() for ent in doc.ents if ent.label_ == "PERSON"]
                tags.extend(persons[:5])  # Limit to 5 person names
                
                # Extract organizations
                orgs = [ent.text.lower() for ent in doc.ents if ent.label_ == "ORG"]
                tags.extend(orgs[:3])  # Limit to 3 organizations
                
                # Extract locations
                locations = [ent.text.lower() for ent in doc.ents if ent.label_ in ["GPE", "LOC"]]
                tags.extend(locations[:3])  # Limit to 3 locations
            
            # Simple keyword extraction based on word frequency
            words = text.lower().split()
            word_freq = {}
            
            # Filter out common stop words
            stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'must', 'can', 'this', 'that', 'these', 'those'}
            
            for word in words:
                word = word.strip('.,!?";()[]{}')
                if len(word) > 3 and word not in stop_words:
                    word_freq[word] = word_freq.get(word, 0) + 1
            
            # Get most frequent words as tags
            frequent_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
            tags.extend([word for word, freq in frequent_words[:10] if freq > 1])
            
            return list(set(tags))  # Remove duplicates
            
        except Exception as e:
            logger.error(f"Error generating tags from text: {e}")
            return []
            
    def extract_entities(self, text):
        """Extract named entities from text"""
        try:
            if not self.nlp or not text:
                return []
                
            doc = self.nlp(text[:10000])  # Limit text size
            entities = []
            
            for ent in doc.ents:
                entities.append({
                    'text': ent.text,
                    'label': ent.label_,
                    'description': spacy.explain(ent.label_),
                    'start': ent.start_char,
                    'end': ent.end_char
                })
                
            return entities
            
        except Exception as e:
            logger.error(f"Error extracting entities: {e}")
            return []
            
    def summarize_text(self, text, max_length=150):
        """Generate summary of text"""
        try:
            if not self.summarizer or not text or len(text) < 100:
                return ""
                
            # Limit input text size for the model
            input_text = text[:1024]
            
            summary = self.summarizer(input_text, max_length=max_length, min_length=30, do_sample=False)
            return summary[0]['summary_text']
            
        except Exception as e:
            logger.error(f"Error summarizing text: {e}")
            return ""
            
    def classify_text(self, text, categories):
        """Classify text into given categories"""
        try:
            if not self.classifier or not text or not categories:
                return {}
                
            # Limit input text size
            input_text = text[:512]
            
            result = self.classifier(input_text, categories)
            
            return {
                'predicted_category': result['labels'][0],
                'scores': dict(zip(result['labels'], result['scores']))
            }
            
        except Exception as e:
            logger.error(f"Error classifying text: {e}")
            return {}

