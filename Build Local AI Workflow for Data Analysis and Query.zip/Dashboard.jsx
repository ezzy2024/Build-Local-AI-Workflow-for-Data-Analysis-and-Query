import { useState, useEffect } from 'react'
import { 
  Activity, 
  FileText, 
  Image, 
  Video, 
  TrendingUp, 
  Clock, 
  Search,
  MessageSquare,
  Plus,
  RefreshCw,
  AlertCircle,
  CheckCircle
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'

const Dashboard = ({ stats, onStatsUpdate }) => {
  const [recentFiles, setRecentFiles] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const [systemStatus, setSystemStatus] = useState({
    fileWatcher: 'active',
    aiService: 'active',
    database: 'active'
  })

  useEffect(() => {
    fetchRecentFiles()
    checkSystemStatus()
  }, [])

  const fetchRecentFiles = async () => {
    try {
      const response = await fetch('/api/files?per_page=5')
      if (response.ok) {
        const data = await response.json()
        setRecentFiles(data.files || [])
      }
    } catch (error) {
      console.error('Failed to fetch recent files:', error)
    }
  }

  const checkSystemStatus = async () => {
    // In a real implementation, you'd check actual service status
    setSystemStatus({
      fileWatcher: 'active',
      aiService: 'active',
      database: 'active'
    })
  }

  const handleRefreshStats = async () => {
    setIsLoading(true)
    try {
      await onStatsUpdate()
      await fetchRecentFiles()
      toast.success('Dashboard refreshed successfully')
    } catch (error) {
      toast.error('Failed to refresh dashboard')
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddDirectory = async () => {
    // This would open a directory picker in a real implementation
    toast.info('Directory picker would open here')
  }

  const getFileTypeIcon = (fileType) => {
    switch (fileType) {
      case 'document':
        return <FileText className="w-4 h-4 text-blue-600" />
      case 'image':
        return <Image className="w-4 h-4 text-green-600" />
      case 'video':
        return <Video className="w-4 h-4 text-purple-600" />
      default:
        return <FileText className="w-4 h-4 text-gray-600" />
    }
  }

  const getStatusIcon = (status) => {
    return status === 'active' ? 
      <CheckCircle className="w-4 h-4 text-green-500" /> : 
      <AlertCircle className="w-4 h-4 text-red-500" />
  }

  const analysisProgress = stats.totalFiles > 0 ? (stats.analyzedFiles / stats.totalFiles) * 100 : 0

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Monitor your local file analysis system
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={handleRefreshStats}
            disabled={isLoading}
            className="flex items-center space-x-2"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </Button>
          
          <Button
            onClick={handleAddDirectory}
            className="flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add Directory</span>
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Files</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalFiles || 0}</div>
            <p className="text-xs text-muted-foreground">
              Files in system
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Documents</CardTitle>
            <FileText className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.documentCount || 0}</div>
            <p className="text-xs text-muted-foreground">
              Text & PDF files
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Images</CardTitle>
            <Image className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.imageCount || 0}</div>
            <p className="text-xs text-muted-foreground">
              Photos & graphics
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Videos</CardTitle>
            <Video className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.videoCount || 0}</div>
            <p className="text-xs text-muted-foreground">
              Video files
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Analysis Progress */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5" />
              <span>Analysis Progress</span>
            </CardTitle>
            <CardDescription>
              AI analysis status of your files
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Overall Progress</span>
              <span className="text-sm text-muted-foreground">
                {stats.analyzedFiles || 0} of {stats.totalFiles || 0} files
              </span>
            </div>
            <Progress value={analysisProgress} className="w-full" />
            <div className="text-center text-sm text-muted-foreground">
              {Math.round(analysisProgress)}% Complete
            </div>
            
            {stats.totalFiles === 0 && (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No files found. Add a directory to get started.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* System Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Activity className="w-5 h-5" />
              <span>System Status</span>
            </CardTitle>
            <CardDescription>
              Service health monitoring
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">File Watcher</span>
              <div className="flex items-center space-x-2">
                {getStatusIcon(systemStatus.fileWatcher)}
                <Badge variant={systemStatus.fileWatcher === 'active' ? 'default' : 'destructive'}>
                  {systemStatus.fileWatcher}
                </Badge>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm">AI Service</span>
              <div className="flex items-center space-x-2">
                {getStatusIcon(systemStatus.aiService)}
                <Badge variant={systemStatus.aiService === 'active' ? 'default' : 'destructive'}>
                  {systemStatus.aiService}
                </Badge>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm">Database</span>
              <div className="flex items-center space-x-2">
                {getStatusIcon(systemStatus.database)}
                <Badge variant={systemStatus.database === 'active' ? 'default' : 'destructive'}>
                  {systemStatus.database}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Files */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Clock className="w-5 h-5" />
            <span>Recent Files</span>
          </CardTitle>
          <CardDescription>
            Recently processed files
          </CardDescription>
        </CardHeader>
        <CardContent>
          {recentFiles.length > 0 ? (
            <div className="space-y-3">
              {recentFiles.map((file, index) => (
                <div key={file.id || index} className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-700 rounded-lg">
                  <div className="flex items-center space-x-3">
                    {getFileTypeIcon(file.file_type)}
                    <div>
                      <p className="font-medium text-sm">{file.filename}</p>
                      <p className="text-xs text-muted-foreground">
                        {file.file_type} • {file.file_size ? `${Math.round(file.file_size / 1024)} KB` : 'Unknown size'}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    {file.last_analyzed && (
                      <Badge variant="secondary" className="text-xs">
                        Analyzed
                      </Badge>
                    )}
                    <span className="text-xs text-muted-foreground">
                      {file.modified_at ? new Date(file.modified_at).toLocaleDateString() : 'Unknown date'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No recent files found</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>
            Common tasks and shortcuts
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button variant="outline" className="flex items-center space-x-2 h-auto p-4">
              <Search className="w-5 h-5" />
              <div className="text-left">
                <div className="font-medium">Search Files</div>
                <div className="text-xs text-muted-foreground">Find content across all files</div>
              </div>
            </Button>
            
            <Button variant="outline" className="flex items-center space-x-2 h-auto p-4">
              <MessageSquare className="w-5 h-5" />
              <div className="text-left">
                <div className="font-medium">AI Chat</div>
                <div className="text-xs text-muted-foreground">Ask questions about your files</div>
              </div>
            </Button>
            
            <Button variant="outline" className="flex items-center space-x-2 h-auto p-4">
              <Plus className="w-5 h-5" />
              <div className="text-left">
                <div className="font-medium">Add Directory</div>
                <div className="text-xs text-muted-foreground">Watch new folder for files</div>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Dashboard

