from flask import Blueprint, request, jsonify
from src.models.file_model import db, FileRecord, SearchIndex
from src.services.search_service import SearchService
from src.services.ai_service import AIService
import json

analysis_bp = Blueprint('analysis', __name__)

@analysis_bp.route('/search', methods=['POST'])
def search_content():
    """Search through analyzed content"""
    try:
        data = request.get_json()
        query = data.get('query', '')
        file_types = data.get('file_types', [])  # Filter by file types
        limit = data.get('limit', 10)
        
        if not query:
            return jsonify({'error': 'Query is required'}), 400
        
        search_service = SearchService()
        results = search_service.search(query, file_types=file_types, limit=limit)
        
        return jsonify({
            'query': query,
            'results': results,
            'total_results': len(results)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@analysis_bp.route('/similar', methods=['POST'])
def find_similar():
    """Find similar files based on content"""
    try:
        data = request.get_json()
        file_id = data.get('file_id')
        limit = data.get('limit', 5)
        
        if not file_id:
            return jsonify({'error': 'File ID is required'}), 400
        
        file_record = FileRecord.query.get_or_404(file_id)
        search_service = SearchService()
        similar_files = search_service.find_similar(file_record, limit=limit)
        
        return jsonify({
            'source_file': file_record.to_dict(),
            'similar_files': [f.to_dict() for f in similar_files]
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@analysis_bp.route('/analyze-batch', methods=['POST'])
def analyze_batch():
    """Analyze multiple files in batch"""
    try:
        data = request.get_json()
        file_ids = data.get('file_ids', [])
        
        if not file_ids:
            return jsonify({'error': 'File IDs are required'}), 400
        
        ai_service = AIService()
        results = []
        
        for file_id in file_ids:
            file_record = FileRecord.query.get(file_id)
            if file_record:
                result = ai_service.analyze_file(file_record.filepath)
                if result:
                    file_record.extracted_text = result.get('text', '')
                    file_record.analysis_results = json.dumps(result.get('analysis', {}))
                    file_record.tags = ','.join(result.get('tags', []))
                    results.append({
                        'file_id': file_id,
                        'status': 'success',
                        'result': result
                    })
                else:
                    results.append({
                        'file_id': file_id,
                        'status': 'failed',
                        'error': 'Analysis failed'
                    })
        
        db.session.commit()
        
        return jsonify({
            'message': f'Processed {len(results)} files',
            'results': results
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@analysis_bp.route('/extract-entities', methods=['POST'])
def extract_entities():
    """Extract entities from text content"""
    try:
        data = request.get_json()
        text = data.get('text', '')
        file_id = data.get('file_id')
        
        if not text and not file_id:
            return jsonify({'error': 'Text or file_id is required'}), 400
        
        if file_id:
            file_record = FileRecord.query.get_or_404(file_id)
            text = file_record.extracted_text or ''
        
        ai_service = AIService()
        entities = ai_service.extract_entities(text)
        
        return jsonify({
            'text': text[:500] + '...' if len(text) > 500 else text,
            'entities': entities
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@analysis_bp.route('/summarize', methods=['POST'])
def summarize_content():
    """Summarize file content"""
    try:
        data = request.get_json()
        file_id = data.get('file_id')
        max_length = data.get('max_length', 150)
        
        if not file_id:
            return jsonify({'error': 'File ID is required'}), 400
        
        file_record = FileRecord.query.get_or_404(file_id)
        
        if not file_record.extracted_text:
            return jsonify({'error': 'File has no extracted text to summarize'}), 400
        
        ai_service = AIService()
        summary = ai_service.summarize_text(file_record.extracted_text, max_length=max_length)
        
        return jsonify({
            'file_id': file_id,
            'filename': file_record.filename,
            'summary': summary,
            'original_length': len(file_record.extracted_text),
            'summary_length': len(summary)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@analysis_bp.route('/classify', methods=['POST'])
def classify_content():
    """Classify file content into categories"""
    try:
        data = request.get_json()
        file_id = data.get('file_id')
        categories = data.get('categories', [])
        
        if not file_id:
            return jsonify({'error': 'File ID is required'}), 400
        
        file_record = FileRecord.query.get_or_404(file_id)
        
        if not file_record.extracted_text:
            return jsonify({'error': 'File has no extracted text to classify'}), 400
        
        ai_service = AIService()
        classification = ai_service.classify_text(file_record.extracted_text, categories)
        
        return jsonify({
            'file_id': file_id,
            'filename': file_record.filename,
            'classification': classification
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@analysis_bp.route('/trends', methods=['GET'])
def get_content_trends():
    """Get trends and patterns from analyzed content"""
    try:
        days = request.args.get('days', 30, type=int)
        
        search_service = SearchService()
        trends = search_service.get_content_trends(days=days)
        
        return jsonify({
            'period_days': days,
            'trends': trends
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

