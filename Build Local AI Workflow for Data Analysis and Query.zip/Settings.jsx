import { useState, useEffect } from 'react'
import { 
  Settings as SettingsIcon, 
  Folder, 
  Bell, 
  Shield, 
  Database, 
  Cpu,
  Save,
  RefreshCw,
  Plus,
  Trash2,
  Eye,
  EyeOff,
  Globe,
  AlertTriangle
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { toast } from 'sonner'

const Settings = () => {
  const [settings, setSettings] = useState({
    watchedDirectories: [],
    notifications: {
      enabled: true,
      newFiles: true,
      analysisComplete: true,
      errors: true
    },
    aiSettings: {
      openaiApiKey: '',
      useExternalAI: false,
      analysisDepth: 'medium'
    },
    privacy: {
      dataRetention: '1year',
      anonymizeData: false,
      shareAnalytics: false
    },
    performance: {
      maxConcurrentAnalysis: 3,
      enableGPU: false,
      cacheResults: true
    }
  })
  
  const [isLoading, setIsLoading] = useState(false)
  const [showApiKey, setShowApiKey] = useState(false)
  const [newDirectory, setNewDirectory] = useState('')

  useEffect(() => {
    loadSettings()
  }, [])

  const loadSettings = async () => {
    try {
      const response = await fetch('/api/settings')
      if (response.ok) {
        const data = await response.json()
        setSettings(prev => ({ ...prev, ...data }))
      }
    } catch (error) {
      console.error('Failed to load settings:', error)
    }
  }

  const saveSettings = async () => {
    setIsLoading(true)
    try {
      const response = await fetch('/api/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(settings)
      })

      if (response.ok) {
        toast.success('Settings saved successfully')
      } else {
        toast.error('Failed to save settings')
      }
    } catch (error) {
      console.error('Failed to save settings:', error)
      toast.error('Failed to save settings')
    } finally {
      setIsLoading(false)
    }
  }

  const addDirectory = async () => {
    if (!newDirectory.trim()) return

    try {
      const response = await fetch('/api/directories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ path: newDirectory })
      })

      if (response.ok) {
        const data = await response.json()
        setSettings(prev => ({
          ...prev,
          watchedDirectories: [...prev.watchedDirectories, data]
        }))
        setNewDirectory('')
        toast.success('Directory added successfully')
      } else {
        toast.error('Failed to add directory')
      }
    } catch (error) {
      console.error('Failed to add directory:', error)
      toast.error('Failed to add directory')
    }
  }

  const removeDirectory = async (directoryId) => {
    try {
      const response = await fetch(`/api/directories/${directoryId}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        setSettings(prev => ({
          ...prev,
          watchedDirectories: prev.watchedDirectories.filter(d => d.id !== directoryId)
        }))
        toast.success('Directory removed successfully')
      } else {
        toast.error('Failed to remove directory')
      }
    } catch (error) {
      console.error('Failed to remove directory:', error)
      toast.error('Failed to remove directory')
    }
  }

  const testNotifications = () => {
    // This would trigger a test notification in a real implementation
    toast.success('Test notification sent!')
  }

  const clearCache = async () => {
    try {
      const response = await fetch('/api/cache', {
        method: 'DELETE'
      })

      if (response.ok) {
        toast.success('Cache cleared successfully')
      } else {
        toast.error('Failed to clear cache')
      }
    } catch (error) {
      console.error('Failed to clear cache:', error)
      toast.error('Failed to clear cache')
    }
  }

  const updateSetting = (path, value) => {
    setSettings(prev => {
      const newSettings = { ...prev }
      const keys = path.split('.')
      let current = newSettings
      
      for (let i = 0; i < keys.length - 1; i++) {
        current = current[keys[i]]
      }
      
      current[keys[keys.length - 1]] = value
      return newSettings
    })
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Settings</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Configure your AI Data Analyzer system
          </p>
        </div>
        
        <Button
          onClick={saveSettings}
          disabled={isLoading}
          className="flex items-center space-x-2"
        >
          <Save className="w-4 h-4" />
          <span>{isLoading ? 'Saving...' : 'Save Settings'}</span>
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Watched Directories */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Folder className="w-5 h-5" />
              <span>Watched Directories</span>
            </CardTitle>
            <CardDescription>
              Directories to monitor for file changes
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex space-x-2">
              <Input
                placeholder="Enter directory path..."
                value={newDirectory}
                onChange={(e) => setNewDirectory(e.target.value)}
                className="flex-1"
              />
              <Button onClick={addDirectory} size="sm">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            
            <div className="space-y-2">
              {settings.watchedDirectories.map((directory, index) => (
                <div key={directory.id || index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <p className="font-medium text-sm">{directory.path}</p>
                    <div className="flex items-center space-x-2 mt-1">
                      <Badge variant={directory.status === 'active' ? 'default' : 'secondary'}>
                        {directory.status || 'active'}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        {directory.file_count || 0} files
                      </span>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeDirectory(directory.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
              
              {settings.watchedDirectories.length === 0 && (
                <p className="text-muted-foreground text-center py-4">
                  No directories being watched
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Bell className="w-5 h-5" />
              <span>Notifications</span>
            </CardTitle>
            <CardDescription>
              Configure system notifications
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="notifications-enabled">Enable Notifications</Label>
              <Switch
                id="notifications-enabled"
                checked={settings.notifications.enabled}
                onCheckedChange={(value) => updateSetting('notifications.enabled', value)}
              />
            </div>
            
            <Separator />
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label htmlFor="notify-new-files">New Files Detected</Label>
                <Switch
                  id="notify-new-files"
                  checked={settings.notifications.newFiles}
                  onCheckedChange={(value) => updateSetting('notifications.newFiles', value)}
                  disabled={!settings.notifications.enabled}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <Label htmlFor="notify-analysis">Analysis Complete</Label>
                <Switch
                  id="notify-analysis"
                  checked={settings.notifications.analysisComplete}
                  onCheckedChange={(value) => updateSetting('notifications.analysisComplete', value)}
                  disabled={!settings.notifications.enabled}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <Label htmlFor="notify-errors">System Errors</Label>
                <Switch
                  id="notify-errors"
                  checked={settings.notifications.errors}
                  onCheckedChange={(value) => updateSetting('notifications.errors', value)}
                  disabled={!settings.notifications.enabled}
                />
              </div>
            </div>
            
            <Button
              variant="outline"
              onClick={testNotifications}
              className="w-full"
              disabled={!settings.notifications.enabled}
            >
              Test Notifications
            </Button>
          </CardContent>
        </Card>

        {/* AI Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Cpu className="w-5 h-5" />
              <span>AI Configuration</span>
            </CardTitle>
            <CardDescription>
              Configure AI analysis settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="openai-key">OpenAI API Key</Label>
              <div className="flex space-x-2">
                <Input
                  id="openai-key"
                  type={showApiKey ? 'text' : 'password'}
                  placeholder="sk-..."
                  value={settings.aiSettings.openaiApiKey}
                  onChange={(e) => updateSetting('aiSettings.openaiApiKey', e.target.value)}
                  className="flex-1"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowApiKey(!showApiKey)}
                >
                  {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Required for advanced AI features and external queries
              </p>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Globe className="w-4 h-4" />
                <Label htmlFor="external-ai">Enable External AI</Label>
              </div>
              <Switch
                id="external-ai"
                checked={settings.aiSettings.useExternalAI}
                onCheckedChange={(value) => updateSetting('aiSettings.useExternalAI', value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="analysis-depth">Analysis Depth</Label>
              <Select
                value={settings.aiSettings.analysisDepth}
                onValueChange={(value) => updateSetting('aiSettings.analysisDepth', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="basic">Basic - Fast processing</SelectItem>
                  <SelectItem value="medium">Medium - Balanced</SelectItem>
                  <SelectItem value="deep">Deep - Comprehensive analysis</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Privacy & Security */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="w-5 h-5" />
              <span>Privacy & Security</span>
            </CardTitle>
            <CardDescription>
              Control your data privacy settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="data-retention">Data Retention</Label>
              <Select
                value={settings.privacy.dataRetention}
                onValueChange={(value) => updateSetting('privacy.dataRetention', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1month">1 Month</SelectItem>
                  <SelectItem value="6months">6 Months</SelectItem>
                  <SelectItem value="1year">1 Year</SelectItem>
                  <SelectItem value="forever">Forever</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="anonymize-data">Anonymize Data</Label>
              <Switch
                id="anonymize-data"
                checked={settings.privacy.anonymizeData}
                onCheckedChange={(value) => updateSetting('privacy.anonymizeData', value)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="share-analytics">Share Anonymous Analytics</Label>
              <Switch
                id="share-analytics"
                checked={settings.privacy.shareAnalytics}
                onCheckedChange={(value) => updateSetting('privacy.shareAnalytics', value)}
              />
            </div>
            
            <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
              <div className="flex items-start space-x-2">
                <AlertTriangle className="w-4 h-4 text-yellow-600 dark:text-yellow-400 mt-0.5" />
                <div className="text-sm">
                  <p className="font-medium text-yellow-800 dark:text-yellow-200">Local Processing</p>
                  <p className="text-yellow-700 dark:text-yellow-300">
                    All data processing happens locally. No files are sent to external servers unless you explicitly enable external AI features.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Performance */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Database className="w-5 h-5" />
              <span>Performance</span>
            </CardTitle>
            <CardDescription>
              Optimize system performance
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="max-concurrent">Max Concurrent Analysis</Label>
              <Select
                value={settings.performance.maxConcurrentAnalysis.toString()}
                onValueChange={(value) => updateSetting('performance.maxConcurrentAnalysis', parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 - Conservative</SelectItem>
                  <SelectItem value="2">2 - Balanced</SelectItem>
                  <SelectItem value="3">3 - Recommended</SelectItem>
                  <SelectItem value="4">4 - Aggressive</SelectItem>
                  <SelectItem value="5">5 - Maximum</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="enable-gpu">Enable GPU Acceleration</Label>
              <Switch
                id="enable-gpu"
                checked={settings.performance.enableGPU}
                onCheckedChange={(value) => updateSetting('performance.enableGPU', value)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="cache-results">Cache Analysis Results</Label>
              <Switch
                id="cache-results"
                checked={settings.performance.cacheResults}
                onCheckedChange={(value) => updateSetting('performance.cacheResults', value)}
              />
            </div>
            
            <Button
              variant="outline"
              onClick={clearCache}
              className="w-full"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Clear Cache
            </Button>
          </CardContent>
        </Card>

        {/* System Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <SettingsIcon className="w-5 h-5" />
              <span>System Information</span>
            </CardTitle>
            <CardDescription>
              Current system status and information
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm">Version</span>
              <Badge variant="secondary">v1.0.0</Badge>
            </div>
            
            <div className="flex justify-between">
              <span className="text-sm">Database Size</span>
              <span className="text-sm text-muted-foreground">~2.3 MB</span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-sm">Cache Size</span>
              <span className="text-sm text-muted-foreground">~15.7 MB</span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-sm">Last Backup</span>
              <span className="text-sm text-muted-foreground">Never</span>
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <Button variant="outline" className="w-full" size="sm">
                Export Settings
              </Button>
              <Button variant="outline" className="w-full" size="sm">
                Import Settings
              </Button>
              <Button variant="outline" className="w-full" size="sm">
                Create Backup
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default Settings

