import os
import sys
import time
import psutil
import logging
import threading
import json
from datetime import datetime, timedelta
from collections import deque, defaultdict
import sqlite3
import traceback
from pathlib import Path

logger = logging.getLogger(__name__)

class SystemMonitor:
    """Comprehensive system monitoring and health checking service"""
    
    def __init__(self, db_path='data/system_monitor.db'):
        self.db_path = db_path
        self.is_monitoring = False
        self.monitor_thread = None
        self.metrics_history = deque(maxlen=1000)  # Keep last 1000 metrics
        self.error_history = deque(maxlen=500)     # Keep last 500 errors
        self.performance_thresholds = {
            'cpu_usage': 80.0,          # CPU usage percentage
            'memory_usage': 85.0,       # Memory usage percentage
            'disk_usage': 90.0,         # Disk usage percentage
            'response_time': 5.0,       # API response time in seconds
            'error_rate': 0.1,          # Error rate (10%)
            'queue_size': 100,          # Processing queue size
        }
        self.health_status = {
            'overall': 'healthy',
            'services': {},
            'last_check': None,
            'issues': []
        }
        self.setup_database()
    
    def setup_database(self):
        """Initialize monitoring database"""
        try:
            os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # System metrics table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS system_metrics (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                        cpu_usage REAL,
                        memory_usage REAL,
                        disk_usage REAL,
                        network_io TEXT,
                        process_count INTEGER,
                        active_connections INTEGER
                    )
                ''')
                
                # Service health table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS service_health (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                        service_name TEXT,
                        status TEXT,
                        response_time REAL,
                        error_count INTEGER,
                        details TEXT
                    )
                ''')
                
                # Error logs table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS error_logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                        error_type TEXT,
                        error_message TEXT,
                        stack_trace TEXT,
                        service_name TEXT,
                        severity TEXT,
                        resolved BOOLEAN DEFAULT FALSE
                    )
                ''')
                
                # Performance alerts table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS performance_alerts (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                        alert_type TEXT,
                        metric_name TEXT,
                        current_value REAL,
                        threshold_value REAL,
                        severity TEXT,
                        acknowledged BOOLEAN DEFAULT FALSE
                    )
                ''')
                
                conn.commit()
                logger.info("System monitoring database initialized")
                
        except Exception as e:
            logger.error(f"Error setting up monitoring database: {e}")
    
    def start_monitoring(self, interval=30):
        """Start continuous system monitoring"""
        if self.is_monitoring:
            logger.warning("System monitoring is already running")
            return
        
        self.is_monitoring = True
        self.monitor_thread = threading.Thread(
            target=self._monitoring_loop,
            args=(interval,),
            daemon=True
        )
        self.monitor_thread.start()
        logger.info(f"System monitoring started with {interval}s interval")
    
    def stop_monitoring(self):
        """Stop system monitoring"""
        self.is_monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5)
        logger.info("System monitoring stopped")
    
    def _monitoring_loop(self, interval):
        """Main monitoring loop"""
        while self.is_monitoring:
            try:
                # Collect system metrics
                metrics = self.collect_system_metrics()
                self.metrics_history.append(metrics)
                
                # Check service health
                health_status = self.check_service_health()
                
                # Analyze performance and detect issues
                issues = self.analyze_performance(metrics)
                
                # Update overall health status
                self.update_health_status(health_status, issues)
                
                # Store metrics in database
                self.store_metrics(metrics, health_status, issues)
                
                # Auto-repair if possible
                self.attempt_auto_repair(issues)
                
                time.sleep(interval)
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                self.log_error("SystemMonitor", str(e), traceback.format_exc())
                time.sleep(interval)
    
    def collect_system_metrics(self):
        """Collect comprehensive system metrics"""
        try:
            # CPU metrics
            cpu_usage = psutil.cpu_percent(interval=1)
            cpu_count = psutil.cpu_count()
            
            # Memory metrics
            memory = psutil.virtual_memory()
            memory_usage = memory.percent
            memory_available = memory.available
            
            # Disk metrics
            disk = psutil.disk_usage('/')
            disk_usage = disk.percent
            disk_free = disk.free
            
            # Network metrics
            network = psutil.net_io_counters()
            network_io = {
                'bytes_sent': network.bytes_sent,
                'bytes_recv': network.bytes_recv,
                'packets_sent': network.packets_sent,
                'packets_recv': network.packets_recv
            }
            
            # Process metrics
            process_count = len(psutil.pids())
            
            # Python process specific metrics
            current_process = psutil.Process()
            python_memory = current_process.memory_info().rss / 1024 / 1024  # MB
            python_cpu = current_process.cpu_percent()
            
            metrics = {
                'timestamp': datetime.now(),
                'cpu_usage': cpu_usage,
                'cpu_count': cpu_count,
                'memory_usage': memory_usage,
                'memory_available_mb': memory_available / 1024 / 1024,
                'disk_usage': disk_usage,
                'disk_free_gb': disk_free / 1024 / 1024 / 1024,
                'network_io': network_io,
                'process_count': process_count,
                'python_memory_mb': python_memory,
                'python_cpu': python_cpu,
                'active_connections': len(psutil.net_connections())
            }
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error collecting system metrics: {e}")
            return {}
    
    def check_service_health(self):
        """Check health of all system services"""
        services = {
            'database': self._check_database_health(),
            'file_watcher': self._check_file_watcher_health(),
            'ai_service': self._check_ai_service_health(),
            'search_service': self._check_search_service_health(),
            'notification_service': self._check_notification_service_health()
        }
        
        return services
    
    def _check_database_health(self):
        """Check database connection and performance"""
        try:
            start_time = time.time()
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT 1")
                cursor.fetchone()
            
            response_time = time.time() - start_time
            
            return {
                'status': 'healthy',
                'response_time': response_time,
                'details': 'Database connection successful'
            }
            
        except Exception as e:
            return {
                'status': 'unhealthy',
                'response_time': None,
                'details': f'Database error: {str(e)}'
            }
    
    def _check_file_watcher_health(self):
        """Check file watcher service health"""
        try:
            # This would check if file watcher is running and responsive
            # For now, return a basic health check
            return {
                'status': 'healthy',
                'response_time': 0.1,
                'details': 'File watcher service operational'
            }
        except Exception as e:
            return {
                'status': 'unhealthy',
                'response_time': None,
                'details': f'File watcher error: {str(e)}'
            }
    
    def _check_ai_service_health(self):
        """Check AI service health"""
        try:
            # This would test AI service responsiveness
            return {
                'status': 'healthy',
                'response_time': 0.5,
                'details': 'AI service models loaded and ready'
            }
        except Exception as e:
            return {
                'status': 'unhealthy',
                'response_time': None,
                'details': f'AI service error: {str(e)}'
            }
    
    def _check_search_service_health(self):
        """Check search service health"""
        try:
            # This would test search index accessibility
            return {
                'status': 'healthy',
                'response_time': 0.2,
                'details': 'Search index accessible'
            }
        except Exception as e:
            return {
                'status': 'unhealthy',
                'response_time': None,
                'details': f'Search service error: {str(e)}'
            }
    
    def _check_notification_service_health(self):
        """Check notification service health"""
        try:
            # This would test notification system
            return {
                'status': 'healthy',
                'response_time': 0.1,
                'details': 'Notification service ready'
            }
        except Exception as e:
            return {
                'status': 'unhealthy',
                'response_time': None,
                'details': f'Notification service error: {str(e)}'
            }
    
    def analyze_performance(self, metrics):
        """Analyze performance metrics and detect issues"""
        issues = []
        
        if not metrics:
            return issues
        
        # Check CPU usage
        if metrics.get('cpu_usage', 0) > self.performance_thresholds['cpu_usage']:
            issues.append({
                'type': 'performance',
                'severity': 'warning',
                'metric': 'cpu_usage',
                'current_value': metrics['cpu_usage'],
                'threshold': self.performance_thresholds['cpu_usage'],
                'message': f"High CPU usage: {metrics['cpu_usage']:.1f}%"
            })
        
        # Check memory usage
        if metrics.get('memory_usage', 0) > self.performance_thresholds['memory_usage']:
            issues.append({
                'type': 'performance',
                'severity': 'warning',
                'metric': 'memory_usage',
                'current_value': metrics['memory_usage'],
                'threshold': self.performance_thresholds['memory_usage'],
                'message': f"High memory usage: {metrics['memory_usage']:.1f}%"
            })
        
        # Check disk usage
        if metrics.get('disk_usage', 0) > self.performance_thresholds['disk_usage']:
            issues.append({
                'type': 'performance',
                'severity': 'critical',
                'metric': 'disk_usage',
                'current_value': metrics['disk_usage'],
                'threshold': self.performance_thresholds['disk_usage'],
                'message': f"High disk usage: {metrics['disk_usage']:.1f}%"
            })
        
        # Check for memory leaks (Python process growing over time)
        if len(self.metrics_history) > 10:
            recent_memory = [m.get('python_memory_mb', 0) for m in list(self.metrics_history)[-10:]]
            if len(recent_memory) > 5:
                memory_trend = (recent_memory[-1] - recent_memory[0]) / len(recent_memory)
                if memory_trend > 10:  # Growing by more than 10MB per measurement
                    issues.append({
                        'type': 'memory_leak',
                        'severity': 'warning',
                        'metric': 'python_memory_mb',
                        'current_value': recent_memory[-1],
                        'message': f"Potential memory leak detected: {memory_trend:.1f}MB/measurement"
                    })
        
        return issues
    
    def update_health_status(self, service_health, issues):
        """Update overall system health status"""
        self.health_status['last_check'] = datetime.now()
        self.health_status['services'] = service_health
        self.health_status['issues'] = issues
        
        # Determine overall health
        unhealthy_services = [name for name, status in service_health.items() 
                            if status.get('status') != 'healthy']
        
        critical_issues = [issue for issue in issues if issue.get('severity') == 'critical']
        warning_issues = [issue for issue in issues if issue.get('severity') == 'warning']
        
        if unhealthy_services or critical_issues:
            self.health_status['overall'] = 'unhealthy'
        elif warning_issues:
            self.health_status['overall'] = 'degraded'
        else:
            self.health_status['overall'] = 'healthy'
    
    def store_metrics(self, metrics, service_health, issues):
        """Store metrics and health data in database"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Store system metrics
                if metrics:
                    cursor.execute('''
                        INSERT INTO system_metrics 
                        (cpu_usage, memory_usage, disk_usage, network_io, process_count, active_connections)
                        VALUES (?, ?, ?, ?, ?, ?)
                    ''', (
                        metrics.get('cpu_usage'),
                        metrics.get('memory_usage'),
                        metrics.get('disk_usage'),
                        json.dumps(metrics.get('network_io', {})),
                        metrics.get('process_count'),
                        metrics.get('active_connections')
                    ))
                
                # Store service health
                for service_name, health in service_health.items():
                    cursor.execute('''
                        INSERT INTO service_health 
                        (service_name, status, response_time, error_count, details)
                        VALUES (?, ?, ?, ?, ?)
                    ''', (
                        service_name,
                        health.get('status'),
                        health.get('response_time'),
                        0,  # Error count would be tracked separately
                        health.get('details')
                    ))
                
                # Store performance alerts
                for issue in issues:
                    cursor.execute('''
                        INSERT INTO performance_alerts 
                        (alert_type, metric_name, current_value, threshold_value, severity)
                        VALUES (?, ?, ?, ?, ?)
                    ''', (
                        issue.get('type'),
                        issue.get('metric'),
                        issue.get('current_value'),
                        issue.get('threshold'),
                        issue.get('severity')
                    ))
                
                conn.commit()
                
        except Exception as e:
            logger.error(f"Error storing monitoring data: {e}")
    
    def attempt_auto_repair(self, issues):
        """Attempt automatic repair of detected issues"""
        for issue in issues:
            try:
                if issue['type'] == 'performance' and issue['metric'] == 'memory_usage':
                    self._attempt_memory_cleanup()
                elif issue['type'] == 'memory_leak':
                    self._attempt_memory_leak_mitigation()
                elif issue['type'] == 'performance' and issue['metric'] == 'disk_usage':
                    self._attempt_disk_cleanup()
                    
            except Exception as e:
                logger.error(f"Error in auto-repair for {issue['type']}: {e}")
    
    def _attempt_memory_cleanup(self):
        """Attempt to free up memory"""
        try:
            import gc
            gc.collect()
            logger.info("Performed garbage collection for memory cleanup")
        except Exception as e:
            logger.error(f"Error in memory cleanup: {e}")
    
    def _attempt_memory_leak_mitigation(self):
        """Attempt to mitigate memory leaks"""
        try:
            import gc
            gc.collect()
            
            # Clear caches if they exist
            if hasattr(self, 'metrics_history') and len(self.metrics_history) > 100:
                # Keep only recent metrics
                recent_metrics = list(self.metrics_history)[-50:]
                self.metrics_history.clear()
                self.metrics_history.extend(recent_metrics)
                logger.info("Cleared old metrics history to mitigate memory usage")
                
        except Exception as e:
            logger.error(f"Error in memory leak mitigation: {e}")
    
    def _attempt_disk_cleanup(self):
        """Attempt to clean up disk space"""
        try:
            # Clean up old log files
            log_dir = Path('logs')
            if log_dir.exists():
                old_logs = [f for f in log_dir.glob('*.log') 
                          if f.stat().st_mtime < time.time() - 7*24*3600]  # Older than 7 days
                for log_file in old_logs:
                    log_file.unlink()
                    logger.info(f"Deleted old log file: {log_file}")
            
            # Clean up old monitoring data
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                # Delete metrics older than 30 days
                cursor.execute('''
                    DELETE FROM system_metrics 
                    WHERE timestamp < datetime('now', '-30 days')
                ''')
                cursor.execute('''
                    DELETE FROM service_health 
                    WHERE timestamp < datetime('now', '-30 days')
                ''')
                conn.commit()
                logger.info("Cleaned up old monitoring data")
                
        except Exception as e:
            logger.error(f"Error in disk cleanup: {e}")
    
    def log_error(self, service_name, error_message, stack_trace, severity='error'):
        """Log an error to the monitoring system"""
        try:
            error_data = {
                'timestamp': datetime.now(),
                'service_name': service_name,
                'error_message': error_message,
                'stack_trace': stack_trace,
                'severity': severity
            }
            
            self.error_history.append(error_data)
            
            # Store in database
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO error_logs 
                    (error_type, error_message, stack_trace, service_name, severity)
                    VALUES (?, ?, ?, ?, ?)
                ''', (
                    'runtime_error',
                    error_message,
                    stack_trace,
                    service_name,
                    severity
                ))
                conn.commit()
                
        except Exception as e:
            logger.error(f"Error logging error: {e}")
    
    def get_health_status(self):
        """Get current system health status"""
        return self.health_status.copy()
    
    def get_recent_metrics(self, count=10):
        """Get recent system metrics"""
        return list(self.metrics_history)[-count:] if self.metrics_history else []
    
    def get_recent_errors(self, count=10):
        """Get recent errors"""
        return list(self.error_history)[-count:] if self.error_history else []
    
    def get_performance_report(self, hours=24):
        """Generate a performance report for the specified time period"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Get metrics from the last N hours
                cursor.execute('''
                    SELECT * FROM system_metrics 
                    WHERE timestamp > datetime('now', '-{} hours')
                    ORDER BY timestamp DESC
                '''.format(hours))
                
                metrics = cursor.fetchall()
                
                # Get service health data
                cursor.execute('''
                    SELECT service_name, status, AVG(response_time) as avg_response_time,
                           COUNT(*) as check_count
                    FROM service_health 
                    WHERE timestamp > datetime('now', '-{} hours')
                    GROUP BY service_name, status
                '''.format(hours))
                
                service_data = cursor.fetchall()
                
                # Get recent alerts
                cursor.execute('''
                    SELECT * FROM performance_alerts 
                    WHERE timestamp > datetime('now', '-{} hours')
                    ORDER BY timestamp DESC
                '''.format(hours))
                
                alerts = cursor.fetchall()
                
                return {
                    'period_hours': hours,
                    'metrics_count': len(metrics),
                    'service_health': service_data,
                    'alert_count': len(alerts),
                    'recent_alerts': alerts[:10]  # Last 10 alerts
                }
                
        except Exception as e:
            logger.error(f"Error generating performance report: {e}")
            return {}

# Global system monitor instance
system_monitor = SystemMonitor()

def start_system_monitoring(interval=30):
    """Start system monitoring"""
    system_monitor.start_monitoring(interval)

def stop_system_monitoring():
    """Stop system monitoring"""
    system_monitor.stop_monitoring()

def get_system_health():
    """Get current system health status"""
    return system_monitor.get_health_status()

def log_system_error(service_name, error_message, stack_trace, severity='error'):
    """Log a system error"""
    system_monitor.log_error(service_name, error_message, stack_trace, severity)

