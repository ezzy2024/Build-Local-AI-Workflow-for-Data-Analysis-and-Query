from src.models.file_model import FileRecord
from src.services.search_service import SearchService
from src.services.ai_service import AIService
from openai import OpenAI
import os
import logging
import json
from datetime import datetime

logger = logging.getLogger(__name__)

class ChatService:
    """Service for conversational AI interactions with local data"""
    
    def __init__(self):
        self.search_service = SearchService()
        self.ai_service = AIService()
        self.setup_openai()
        
    def setup_openai(self):
        """Setup OpenAI client for conversational AI"""
        try:
            # OpenAI API key should be set in environment variables
            api_key = os.getenv('OPENAI_API_KEY')
            api_base = os.getenv('OPENAI_API_BASE')
            
            if api_key:
                if api_base:
                    self.openai_client = OpenAI(api_key=api_key, base_url=api_base)
                else:
                    self.openai_client = OpenAI(api_key=api_key)
                self.openai_available = True
                logger.info("OpenAI client initialized")
            else:
                self.openai_available = False
                self.openai_client = None
                logger.warning("OpenAI API key not found. Chat functionality will be limited.")
                
        except Exception as e:
            logger.error(f"Error setting up OpenAI: {e}")
            self.openai_available = False
            self.openai_client = None
            
    def generate_response(self, user_message, context_files=None):
        """Generate conversational response based on user message and context"""
        try:
            # Search for relevant files if no specific context provided
            if not context_files:
                search_results = self.search_service.search(user_message, limit=5)
                context_files = []
                
                for result in search_results:
                    if result['score'] > 0.1:  # Only include relevant results
                        context_files.append({
                            'filename': result['file']['filename'],
                            'content': result['file']['extracted_text'][:1500] if result['file']['extracted_text'] else '',
                            'file_type': result['file']['file_type'],
                            'relevance_score': result['score']
                        })
            
            # Prepare context for AI
            context_text = self.prepare_context(context_files)
            
            if self.openai_available:
                return self.generate_openai_response(user_message, context_text)
            else:
                return self.generate_fallback_response(user_message, context_files)
                
        except Exception as e:
            logger.error(f"Error generating response: {e}")
            return "I'm sorry, I encountered an error while processing your request."
            
    def generate_openai_response(self, user_message, context_text):
        """Generate response using OpenAI API"""
        try:
            system_prompt = """You are an AI assistant that helps users analyze and query their local files. 
            You have access to the content of various documents, images, and videos that have been analyzed and indexed.
            
            Your role is to:
            1. Answer questions about the content of the user's files
            2. Provide summaries and insights from the analyzed data
            3. Help users find specific information across their files
            4. Explain concepts found in their documents
            5. Compare and contrast information from different files
            
            Always base your responses on the provided context from the user's files. If you don't have enough information 
            from the context to answer a question, say so clearly. Be helpful, accurate, and concise.
            
            The context below contains relevant information from the user's files:"""
            
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Context from files:\n{context_text}\n\nUser question: {user_message}"}
            ]
            
            response = self.openai_client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=messages,
                max_tokens=500,
                temperature=0.7
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            logger.error(f"Error with OpenAI API: {e}")
            return self.generate_fallback_response(user_message, [])
            
    def generate_fallback_response(self, user_message, context_files):
        """Generate basic response without external AI"""
        try:
            # Simple keyword-based responses
            user_message_lower = user_message.lower()
            
            if any(word in user_message_lower for word in ['how many', 'count', 'total']):
                total_files = FileRecord.query.count()
                return f"I found {total_files} files in your system. You can ask me about specific files or search for content."
            
            elif any(word in user_message_lower for word in ['what', 'tell me about', 'describe']):
                if context_files:
                    file_info = []
                    for ctx in context_files[:3]:  # Limit to 3 files
                        file_info.append(f"- {ctx['filename']}: {ctx['content'][:200]}...")
                    return f"Here's what I found:\n" + "\n".join(file_info)
                else:
                    return "I couldn't find specific information about that. Try searching for specific keywords or file names."
            
            elif any(word in user_message_lower for word in ['search', 'find', 'look for']):
                if context_files:
                    filenames = [ctx['filename'] for ctx in context_files[:5]]
                    return f"I found these relevant files: {', '.join(filenames)}"
                else:
                    return "I couldn't find any files matching your search. Try different keywords."
            
            else:
                if context_files:
                    return f"I found {len(context_files)} relevant files. Here are the most relevant ones: {', '.join([ctx['filename'] for ctx in context_files[:3]])}"
                else:
                    return "I understand you're asking about your files, but I need more specific information to help you. Try asking about specific topics, file names, or content."
                    
        except Exception as e:
            logger.error(f"Error generating fallback response: {e}")
            return "I'm having trouble processing your request right now."
            
    def generate_response_stream(self, user_message, context_files=None):
        """Generate streaming response for real-time chat"""
        try:
            # For now, just yield the complete response
            # In a full implementation, you'd stream tokens from the AI model
            response = self.generate_response(user_message, context_files)
            
            # Simulate streaming by yielding words
            words = response.split()
            for word in words:
                yield word + " "
                
        except Exception as e:
            logger.error(f"Error generating streaming response: {e}")
            yield "Error processing request."
            
    def generate_suggestions(self, file_record):
        """Generate suggested questions based on file content"""
        try:
            suggestions = []
            
            if file_record.file_type == 'document':
                suggestions = [
                    f"What is the main topic of {file_record.filename}?",
                    f"Summarize the content of {file_record.filename}",
                    f"What are the key points in {file_record.filename}?",
                    f"Are there any important dates mentioned in {file_record.filename}?",
                    f"What entities are mentioned in {file_record.filename}?"
                ]
            elif file_record.file_type == 'image':
                suggestions = [
                    f"What can you see in {file_record.filename}?",
                    f"Describe the content of {file_record.filename}",
                    f"What text is visible in {file_record.filename}?",
                    f"What are the main colors in {file_record.filename}?",
                    f"What objects are detected in {file_record.filename}?"
                ]
            elif file_record.file_type == 'video':
                suggestions = [
                    f"What is discussed in {file_record.filename}?",
                    f"How long is {file_record.filename}?",
                    f"What is the main content of {file_record.filename}?",
                    f"Are there any spoken words in {file_record.filename}?",
                    f"What happens in {file_record.filename}?"
                ]
            
            return suggestions
            
        except Exception as e:
            logger.error(f"Error generating suggestions: {e}")
            return []
            
    def explain_concept(self, file_record, concept, additional_context=""):
        """Explain a specific concept from a file"""
        try:
            if not file_record.extracted_text:
                return "This file doesn't have any extracted text to explain concepts from."
            
            # Find relevant sections mentioning the concept
            text = file_record.extracted_text.lower()
            concept_lower = concept.lower()
            
            if concept_lower not in text:
                return f"I couldn't find any mention of '{concept}' in {file_record.filename}."
            
            # Extract sentences containing the concept
            sentences = file_record.extracted_text.split('.')
            relevant_sentences = [s.strip() for s in sentences if concept_lower in s.lower()]
            
            if not relevant_sentences:
                return f"I found '{concept}' mentioned in {file_record.filename} but couldn't extract clear explanations."
            
            # Use AI to generate explanation if available
            if self.openai_available:
                try:
                    context = ". ".join(relevant_sentences[:3])  # Use first 3 relevant sentences
                    
                    messages = [
                        {"role": "system", "content": "You are an AI assistant that explains concepts found in documents. Provide clear, concise explanations based on the given context."},
                        {"role": "user", "content": f"Based on this context from {file_record.filename}: '{context}', please explain what '{concept}' means. {additional_context}"}
                    ]
                    
                    response = self.openai_client.chat.completions.create(
                        model="gpt-3.5-turbo",
                        messages=messages,
                        max_tokens=300,
                        temperature=0.5
                    )
                    
                    return response.choices[0].message.content.strip()
                    
                except Exception as e:
                    logger.warning(f"OpenAI explanation failed: {e}")
            
            # Fallback explanation
            explanation = f"Based on {file_record.filename}, here's what I found about '{concept}':\n\n"
            explanation += ". ".join(relevant_sentences[:2])  # Show first 2 relevant sentences
            
            return explanation
            
        except Exception as e:
            logger.error(f"Error explaining concept: {e}")
            return "I encountered an error while trying to explain that concept."
            
    def compare_files(self, files, comparison_aspect="general"):
        """Compare content between multiple files"""
        try:
            if len(files) < 2:
                return "I need at least 2 files to make a comparison."
            
            file_summaries = []
            for file_record in files:
                summary = {
                    'filename': file_record.filename,
                    'file_type': file_record.file_type,
                    'content_preview': file_record.extracted_text[:500] if file_record.extracted_text else "No text content",
                    'tags': file_record.tags.split(',') if file_record.tags else []
                }
                file_summaries.append(summary)
            
            if self.openai_available:
                try:
                    context = json.dumps(file_summaries, indent=2)
                    
                    messages = [
                        {"role": "system", "content": "You are an AI assistant that compares and contrasts different files. Provide detailed comparisons highlighting similarities and differences."},
                        {"role": "user", "content": f"Please compare these files focusing on {comparison_aspect}:\n{context}"}
                    ]
                    
                    response = self.openai_client.chat.completions.create(
                        model="gpt-3.5-turbo",
                        messages=messages,
                        max_tokens=600,
                        temperature=0.5
                    )
                    
                    return response.choices[0].message.content.strip()
                    
                except Exception as e:
                    logger.warning(f"OpenAI comparison failed: {e}")
            
            # Fallback comparison
            comparison = f"Comparison of {len(files)} files:\n\n"
            
            for i, file_record in enumerate(files, 1):
                comparison += f"{i}. {file_record.filename} ({file_record.file_type})\n"
                if file_record.extracted_text:
                    comparison += f"   Content preview: {file_record.extracted_text[:200]}...\n"
                if file_record.tags:
                    comparison += f"   Tags: {file_record.tags}\n"
                comparison += "\n"
            
            return comparison
            
        except Exception as e:
            logger.error(f"Error comparing files: {e}")
            return "I encountered an error while comparing the files."
            
    def prepare_context(self, context_files):
        """Prepare context text from files for AI processing"""
        try:
            if not context_files:
                return "No relevant files found."
            
            context_parts = []
            
            for i, ctx in enumerate(context_files[:5], 1):  # Limit to 5 files
                context_part = f"File {i}: {ctx['filename']} ({ctx['file_type']})\n"
                
                if ctx.get('content'):
                    # Limit content length to avoid token limits
                    content = ctx['content'][:1000]
                    context_part += f"Content: {content}\n"
                
                if ctx.get('relevance_score'):
                    context_part += f"Relevance: {ctx['relevance_score']:.2f}\n"
                
                context_parts.append(context_part)
            
            return "\n---\n".join(context_parts)
            
        except Exception as e:
            logger.error(f"Error preparing context: {e}")
            return "Error preparing context from files."

