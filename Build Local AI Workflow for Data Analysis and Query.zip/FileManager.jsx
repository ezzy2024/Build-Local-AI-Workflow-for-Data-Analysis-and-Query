import { useState, useEffect } from 'react'
import { 
  Files, 
  Search, 
  Filter, 
  RefreshCw, 
  Plus,
  FileText,
  Image,
  Video,
  MoreVertical,
  Eye,
  Download,
  Trash2,
  Calendar,
  HardDrive
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu'
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { toast } from 'sonner'

const FileManager = ({ onStatsUpdate }) => {
  const [files, setFiles] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedFileType, setSelectedFileType] = useState('all')
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)

  useEffect(() => {
    fetchFiles()
  }, [currentPage, selectedFileType, searchQuery])

  const fetchFiles = async () => {
    setIsLoading(true)
    try {
      const params = new URLSearchParams({
        page: currentPage.toString(),
        per_page: '20'
      })
      
      if (selectedFileType !== 'all') {
        params.append('type', selectedFileType)
      }
      
      if (searchQuery) {
        params.append('search', searchQuery)
      }

      const response = await fetch(`/api/files?${params}`)
      if (response.ok) {
        const data = await response.json()
        setFiles(data.files || [])
        setTotalPages(data.pages || 1)
      } else {
        toast.error('Failed to fetch files')
      }
    } catch (error) {
      console.error('Failed to fetch files:', error)
      toast.error('Failed to fetch files')
    } finally {
      setIsLoading(false)
    }
  }

  const handleAnalyzeFile = async (fileId) => {
    try {
      const response = await fetch(`/api/files/${fileId}/analyze`, {
        method: 'POST'
      })
      
      if (response.ok) {
        toast.success('File analysis started')
        fetchFiles()
        onStatsUpdate()
      } else {
        toast.error('Failed to start analysis')
      }
    } catch (error) {
      console.error('Failed to analyze file:', error)
      toast.error('Failed to analyze file')
    }
  }

  const handleAddDirectory = async () => {
    // In a real implementation, this would open a directory picker
    toast.info('Directory picker would open here')
  }

  const getFileTypeIcon = (fileType) => {
    switch (fileType) {
      case 'document':
        return <FileText className="w-5 h-5 text-blue-600" />
      case 'image':
        return <Image className="w-5 h-5 text-green-600" />
      case 'video':
        return <Video className="w-5 h-5 text-purple-600" />
      default:
        return <FileText className="w-5 h-5 text-gray-600" />
    }
  }

  const formatFileSize = (bytes) => {
    if (!bytes) return 'Unknown'
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(1024))
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i]
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'Unknown'
    return new Date(dateString).toLocaleDateString()
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">File Manager</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Manage and analyze your local files
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            onClick={fetchFiles}
            disabled={isLoading}
            className="flex items-center space-x-2"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </Button>
          
          <Button
            onClick={handleAddDirectory}
            className="flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add Directory</span>
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search files by name or content..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <Select value={selectedFileType} onValueChange={setSelectedFileType}>
              <SelectTrigger className="w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Files</SelectItem>
                <SelectItem value="document">Documents</SelectItem>
                <SelectItem value="image">Images</SelectItem>
                <SelectItem value="video">Videos</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Files List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Files className="w-5 h-5" />
            <span>Files ({files.length})</span>
          </CardTitle>
          <CardDescription>
            Your analyzed and indexed files
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <RefreshCw className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : files.length > 0 ? (
            <div className="space-y-3">
              {files.map((file) => (
                <div key={file.id} className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-center space-x-4 flex-1">
                    {getFileTypeIcon(file.file_type)}
                    
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-sm truncate">{file.filename}</h3>
                      <div className="flex items-center space-x-4 text-xs text-muted-foreground mt-1">
                        <span className="flex items-center space-x-1">
                          <HardDrive className="w-3 h-3" />
                          <span>{formatFileSize(file.file_size)}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <Calendar className="w-3 h-3" />
                          <span>{formatDate(file.modified_at)}</span>
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Badge variant={file.last_analyzed ? 'default' : 'secondary'}>
                        {file.last_analyzed ? 'Analyzed' : 'Pending'}
                      </Badge>
                      
                      <Badge variant="outline" className="capitalize">
                        {file.file_type}
                      </Badge>
                    </div>
                  </div>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Eye className="w-4 h-4 mr-2" />
                        View Details
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleAnalyzeFile(file.id)}>
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Re-analyze
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-red-600">
                        <Trash2 className="w-4 h-4 mr-2" />
                        Remove from Index
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Files className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-muted-foreground mb-2">No files found</h3>
              <p className="text-muted-foreground mb-4">
                {searchQuery || selectedFileType !== 'all' 
                  ? 'Try adjusting your search criteria' 
                  : 'Add a directory to start analyzing files'
                }
              </p>
              {!searchQuery && selectedFileType === 'all' && (
                <Button onClick={handleAddDirectory}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Directory
                </Button>
              )}
            </div>
          )}
          
          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between mt-6 pt-4 border-t">
              <p className="text-sm text-muted-foreground">
                Page {currentPage} of {totalPages}
              </p>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                >
                  Previous
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default FileManager

