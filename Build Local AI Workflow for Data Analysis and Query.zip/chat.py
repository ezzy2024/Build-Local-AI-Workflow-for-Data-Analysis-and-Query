from flask import Blueprint, request, jsonify, Response
from src.models.file_model import db, FileRecord
from src.services.chat_service import ChatService
from src.services.external_ai_service import ExternalAIService
import json

chat_bp = Blueprint('chat', __name__)

@chat_bp.route('/chat', methods=['POST'])
def chat():
    """Main chat endpoint for conversational queries"""
    try:
        data = request.get_json()
        message = data.get('message', '')
        context_files = data.get('context_files', [])  # Optional file IDs for context
        use_external_ai = data.get('use_external_ai', False)
        
        if not message:
            return jsonify({'error': 'Message is required'}), 400
        
        chat_service = ChatService()
        
        # Get context from specified files
        context = []
        if context_files:
            for file_id in context_files:
                file_record = FileRecord.query.get(file_id)
                if file_record and file_record.extracted_text:
                    context.append({
                        'filename': file_record.filename,
                        'content': file_record.extracted_text[:2000],  # Limit context size
                        'file_type': file_record.file_type
                    })
        
        # Generate response
        if use_external_ai:
            external_service = ExternalAIService()
            response = external_service.query_with_context(message, context)
        else:
            response = chat_service.generate_response(message, context)
        
        return jsonify({
            'message': message,
            'response': response,
            'context_files_used': len(context),
            'used_external_ai': use_external_ai
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@chat_bp.route('/chat/stream', methods=['POST'])
def chat_stream():
    """Streaming chat endpoint for real-time responses"""
    try:
        data = request.get_json()
        message = data.get('message', '')
        context_files = data.get('context_files', [])
        
        if not message:
            return jsonify({'error': 'Message is required'}), 400
        
        chat_service = ChatService()
        
        # Get context from specified files
        context = []
        if context_files:
            for file_id in context_files:
                file_record = FileRecord.query.get(file_id)
                if file_record and file_record.extracted_text:
                    context.append({
                        'filename': file_record.filename,
                        'content': file_record.extracted_text[:2000],
                        'file_type': file_record.file_type
                    })
        
        def generate():
            for chunk in chat_service.generate_response_stream(message, context):
                yield f"data: {json.dumps({'chunk': chunk})}\n\n"
            yield f"data: {json.dumps({'done': True})}\n\n"
        
        return Response(generate(), mimetype='text/plain')
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@chat_bp.route('/chat/suggestions', methods=['POST'])
def get_suggestions():
    """Get suggested questions based on file content"""
    try:
        data = request.get_json()
        file_id = data.get('file_id')
        
        if not file_id:
            return jsonify({'error': 'File ID is required'}), 400
        
        file_record = FileRecord.query.get_or_404(file_id)
        
        if not file_record.extracted_text:
            return jsonify({'error': 'File has no content to generate suggestions from'}), 400
        
        chat_service = ChatService()
        suggestions = chat_service.generate_suggestions(file_record)
        
        return jsonify({
            'file_id': file_id,
            'filename': file_record.filename,
            'suggestions': suggestions
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@chat_bp.route('/chat/explain', methods=['POST'])
def explain_content():
    """Explain specific content or concepts from files"""
    try:
        data = request.get_json()
        file_id = data.get('file_id')
        concept = data.get('concept', '')
        context = data.get('context', '')  # Additional context
        
        if not file_id:
            return jsonify({'error': 'File ID is required'}), 400
        
        file_record = FileRecord.query.get_or_404(file_id)
        
        chat_service = ChatService()
        explanation = chat_service.explain_concept(file_record, concept, context)
        
        return jsonify({
            'file_id': file_id,
            'filename': file_record.filename,
            'concept': concept,
            'explanation': explanation
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@chat_bp.route('/chat/compare', methods=['POST'])
def compare_files():
    """Compare content between multiple files"""
    try:
        data = request.get_json()
        file_ids = data.get('file_ids', [])
        comparison_aspect = data.get('aspect', 'general')  # What to compare
        
        if len(file_ids) < 2:
            return jsonify({'error': 'At least 2 files are required for comparison'}), 400
        
        files = []
        for file_id in file_ids:
            file_record = FileRecord.query.get(file_id)
            if file_record:
                files.append(file_record)
        
        if len(files) < 2:
            return jsonify({'error': 'Could not find enough valid files'}), 400
        
        chat_service = ChatService()
        comparison = chat_service.compare_files(files, comparison_aspect)
        
        return jsonify({
            'files': [{'id': f.id, 'filename': f.filename} for f in files],
            'comparison_aspect': comparison_aspect,
            'comparison': comparison
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@chat_bp.route('/chat/history', methods=['GET'])
def get_chat_history():
    """Get chat history (if implemented with session storage)"""
    try:
        # This would require implementing session storage for chat history
        # For now, return empty history
        return jsonify({
            'history': [],
            'message': 'Chat history not implemented yet'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@chat_bp.route('/chat/clear', methods=['POST'])
def clear_chat_history():
    """Clear chat history"""
    try:
        # This would clear the session storage
        return jsonify({
            'message': 'Chat history cleared'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

