import os
import sys
import logging
import traceback
import inspect
import ast
import re
import json
import time
from datetime import datetime, timedelta
from collections import defaultdict, Counter
import sqlite3
from pathlib import Path
import subprocess
import importlib.util

logger = logging.getLogger(__name__)

class AutoDebugger:
    """Automated debugging and error resolution system"""
    
    def __init__(self, db_path='data/debug_logs.db'):
        self.db_path = db_path
        self.error_patterns = {}
        self.solution_database = {}
        self.code_analysis_cache = {}
        self.debug_sessions = {}
        self.auto_fix_enabled = True
        self.setup_database()
        self.load_error_patterns()
        self.load_solution_database()
    
    def setup_database(self):
        """Initialize debugging database"""
        try:
            os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Debug sessions table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS debug_sessions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        session_id TEXT UNIQUE,
                        start_time DATETIME DEFAULT CURRENT_TIMESTAMP,
                        end_time DATETIME,
                        error_type TEXT,
                        error_message TEXT,
                        stack_trace TEXT,
                        file_path TEXT,
                        line_number INTEGER,
                        function_name TEXT,
                        resolution_status TEXT,
                        auto_fixed BOOLEAN DEFAULT FALSE,
                        fix_applied TEXT,
                        success_rate REAL
                    )
                ''')
                
                # Error patterns table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS error_patterns (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        pattern_name TEXT UNIQUE,
                        error_regex TEXT,
                        description TEXT,
                        common_causes TEXT,
                        suggested_fixes TEXT,
                        success_rate REAL DEFAULT 0.0,
                        usage_count INTEGER DEFAULT 0
                    )
                ''')
                
                # Code analysis table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS code_analysis (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        file_path TEXT,
                        analysis_time DATETIME DEFAULT CURRENT_TIMESTAMP,
                        complexity_score REAL,
                        potential_issues TEXT,
                        suggestions TEXT,
                        code_quality_score REAL
                    )
                ''')
                
                # Auto fixes table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS auto_fixes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        fix_id TEXT UNIQUE,
                        error_pattern TEXT,
                        fix_description TEXT,
                        fix_code TEXT,
                        success_count INTEGER DEFAULT 0,
                        failure_count INTEGER DEFAULT 0,
                        last_used DATETIME,
                        enabled BOOLEAN DEFAULT TRUE
                    )
                ''')
                
                conn.commit()
                logger.info("Auto debugger database initialized")
                
        except Exception as e:
            logger.error(f"Error setting up debug database: {e}")
    
    def load_error_patterns(self):
        """Load common error patterns and their solutions"""
        self.error_patterns = {
            'import_error': {
                'pattern': r'ModuleNotFoundError: No module named [\'"]([^\'"]+)[\'"]',
                'description': 'Missing Python module',
                'solutions': [
                    'pip install {module}',
                    'conda install {module}',
                    'Check if module name is correct',
                    'Verify virtual environment is activated'
                ]
            },
            'file_not_found': {
                'pattern': r'FileNotFoundError: \[Errno 2\] No such file or directory: [\'"]([^\'"]+)[\'"]',
                'description': 'File or directory not found',
                'solutions': [
                    'Create missing directory: os.makedirs(dirname, exist_ok=True)',
                    'Check file path spelling and case sensitivity',
                    'Verify file exists before accessing',
                    'Use absolute paths instead of relative paths'
                ]
            },
            'permission_error': {
                'pattern': r'PermissionError: \[Errno 13\] Permission denied: [\'"]([^\'"]+)[\'"]',
                'description': 'Permission denied accessing file/directory',
                'solutions': [
                    'Change file permissions: chmod 644 {file}',
                    'Run with appropriate user permissions',
                    'Check if file is locked by another process',
                    'Use sudo if administrative access is needed'
                ]
            },
            'connection_error': {
                'pattern': r'ConnectionError|ConnectionRefusedError|TimeoutError',
                'description': 'Network connection issues',
                'solutions': [
                    'Check network connectivity',
                    'Verify server is running and accessible',
                    'Increase connection timeout',
                    'Implement retry mechanism with exponential backoff'
                ]
            },
            'memory_error': {
                'pattern': r'MemoryError|OutOfMemoryError',
                'description': 'Insufficient memory',
                'solutions': [
                    'Process data in smaller chunks',
                    'Implement memory-efficient algorithms',
                    'Clear unused variables: del variable',
                    'Use generators instead of lists for large datasets'
                ]
            },
            'type_error': {
                'pattern': r'TypeError: (.+)',
                'description': 'Type-related error',
                'solutions': [
                    'Check variable types before operations',
                    'Add type checking: isinstance(var, expected_type)',
                    'Convert types explicitly: str(var), int(var), etc.',
                    'Use type hints for better code clarity'
                ]
            },
            'key_error': {
                'pattern': r'KeyError: [\'"]([^\'"]+)[\'"]',
                'description': 'Dictionary key not found',
                'solutions': [
                    'Use dict.get(key, default) instead of dict[key]',
                    'Check if key exists: if key in dict',
                    'Use try-except block for key access',
                    'Initialize dictionary with default values'
                ]
            },
            'index_error': {
                'pattern': r'IndexError: (.+)',
                'description': 'List index out of range',
                'solutions': [
                    'Check list length before accessing: if len(list) > index',
                    'Use try-except block for index access',
                    'Iterate with enumerate() to avoid index errors',
                    'Use list slicing with safe bounds'
                ]
            }
        }
    
    def load_solution_database(self):
        """Load database of known solutions"""
        self.solution_database = {
            'database_locked': {
                'description': 'SQLite database is locked',
                'solutions': [
                    'Close all database connections properly',
                    'Use context managers: with sqlite3.connect(db) as conn',
                    'Add connection timeout: sqlite3.connect(db, timeout=30)',
                    'Check for long-running transactions'
                ],
                'code_fix': '''
# Proper database connection handling
import sqlite3
import time

def safe_db_operation(db_path, operation_func, max_retries=3):
    for attempt in range(max_retries):
        try:
            with sqlite3.connect(db_path, timeout=30) as conn:
                return operation_func(conn)
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e) and attempt < max_retries - 1:
                time.sleep(0.1 * (2 ** attempt))  # Exponential backoff
                continue
            raise
'''
            },
            'port_already_in_use': {
                'description': 'Port is already in use by another process',
                'solutions': [
                    'Use a different port number',
                    'Kill process using the port: lsof -ti:PORT | xargs kill',
                    'Find available port automatically',
                    'Configure port in environment variables'
                ],
                'code_fix': '''
import socket

def find_free_port(start_port=5000, max_port=65535):
    """Find an available port starting from start_port"""
    for port in range(start_port, max_port):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(('localhost', port))
                return port
        except OSError:
            continue
    raise RuntimeError("No free ports available")
'''
            },
            'circular_import': {
                'description': 'Circular import dependency',
                'solutions': [
                    'Restructure code to avoid circular dependencies',
                    'Move shared code to a separate module',
                    'Use import statements inside functions',
                    'Implement dependency injection pattern'
                ],
                'code_fix': '''
# Instead of importing at module level, import inside functions
def get_processor():
    from .file_processor import FileProcessor  # Import inside function
    return FileProcessor()
'''
            }
        }
    
    def analyze_error(self, error_type, error_message, stack_trace, file_path=None, line_number=None):
        """Analyze an error and provide debugging information"""
        session_id = f"debug_{int(time.time())}_{hash(error_message) % 10000}"
        
        debug_session = {
            'session_id': session_id,
            'start_time': datetime.now(),
            'error_type': error_type,
            'error_message': error_message,
            'stack_trace': stack_trace,
            'file_path': file_path,
            'line_number': line_number,
            'analysis': {},
            'solutions': [],
            'auto_fix_applied': False
        }
        
        # Pattern matching
        matched_patterns = self.match_error_patterns(error_message)
        debug_session['analysis']['matched_patterns'] = matched_patterns
        
        # Code analysis if file path is available
        if file_path and os.path.exists(file_path):
            code_analysis = self.analyze_code_file(file_path, line_number)
            debug_session['analysis']['code_analysis'] = code_analysis
        
        # Generate solutions
        solutions = self.generate_solutions(error_type, error_message, matched_patterns)
        debug_session['solutions'] = solutions
        
        # Attempt auto-fix if enabled
        if self.auto_fix_enabled:
            auto_fix_result = self.attempt_auto_fix(debug_session)
            debug_session['auto_fix_result'] = auto_fix_result
        
        # Store debug session
        self.debug_sessions[session_id] = debug_session
        self.store_debug_session(debug_session)
        
        return debug_session
    
    def match_error_patterns(self, error_message):
        """Match error message against known patterns"""
        matched_patterns = []
        
        for pattern_name, pattern_info in self.error_patterns.items():
            if re.search(pattern_info['pattern'], error_message, re.IGNORECASE):
                matched_patterns.append({
                    'name': pattern_name,
                    'description': pattern_info['description'],
                    'solutions': pattern_info['solutions']
                })
        
        return matched_patterns
    
    def analyze_code_file(self, file_path, error_line=None):
        """Analyze code file for potential issues"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                code_content = f.read()
            
            # Parse AST for code analysis
            try:
                tree = ast.parse(code_content)
                analysis = self.analyze_ast(tree, error_line)
            except SyntaxError as e:
                analysis = {
                    'syntax_error': True,
                    'error_line': e.lineno,
                    'error_message': str(e)
                }
            
            # Additional static analysis
            static_analysis = self.perform_static_analysis(code_content, error_line)
            analysis.update(static_analysis)
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing code file {file_path}: {e}")
            return {'error': str(e)}
    
    def analyze_ast(self, tree, error_line=None):
        """Analyze Abstract Syntax Tree for code issues"""
        analysis = {
            'complexity_score': 0,
            'potential_issues': [],
            'suggestions': [],
            'imports': [],
            'functions': [],
            'classes': []
        }
        
        class CodeAnalyzer(ast.NodeVisitor):
            def __init__(self):
                self.complexity = 0
                self.issues = []
                self.suggestions = []
                self.current_function = None
                self.nested_level = 0
            
            def visit_Import(self, node):
                for alias in node.names:
                    analysis['imports'].append(alias.name)
                self.generic_visit(node)
            
            def visit_ImportFrom(self, node):
                if node.module:
                    for alias in node.names:
                        analysis['imports'].append(f"{node.module}.{alias.name}")
                self.generic_visit(node)
            
            def visit_FunctionDef(self, node):
                analysis['functions'].append({
                    'name': node.name,
                    'line': node.lineno,
                    'args': len(node.args.args),
                    'decorators': len(node.decorator_list)
                })
                
                # Check function complexity
                if len(node.body) > 20:
                    self.issues.append(f"Function '{node.name}' is too long ({len(node.body)} statements)")
                
                if len(node.args.args) > 5:
                    self.issues.append(f"Function '{node.name}' has too many parameters ({len(node.args.args)})")
                
                self.current_function = node.name
                self.nested_level += 1
                self.generic_visit(node)
                self.nested_level -= 1
                self.current_function = None
            
            def visit_ClassDef(self, node):
                analysis['classes'].append({
                    'name': node.name,
                    'line': node.lineno,
                    'methods': len([n for n in node.body if isinstance(n, ast.FunctionDef)]),
                    'bases': len(node.bases)
                })
                self.generic_visit(node)
            
            def visit_If(self, node):
                self.complexity += 1
                if self.nested_level > 3:
                    self.issues.append(f"Deep nesting detected (level {self.nested_level})")
                self.generic_visit(node)
            
            def visit_For(self, node):
                self.complexity += 1
                self.generic_visit(node)
            
            def visit_While(self, node):
                self.complexity += 1
                self.generic_visit(node)
            
            def visit_Try(self, node):
                if not node.handlers:
                    self.issues.append("Try block without exception handlers")
                for handler in node.handlers:
                    if handler.type is None:
                        self.issues.append("Bare except clause - should specify exception type")
                self.generic_visit(node)
        
        analyzer = CodeAnalyzer()
        analyzer.visit(tree)
        
        analysis['complexity_score'] = analyzer.complexity
        analysis['potential_issues'].extend(analyzer.issues)
        analysis['suggestions'].extend(analyzer.suggestions)
        
        return analysis
    
    def perform_static_analysis(self, code_content, error_line=None):
        """Perform additional static code analysis"""
        analysis = {
            'line_count': len(code_content.split('\n')),
            'code_smells': [],
            'security_issues': [],
            'performance_issues': []
        }
        
        lines = code_content.split('\n')
        
        # Check for common code smells
        for i, line in enumerate(lines, 1):
            line_stripped = line.strip()
            
            # Long lines
            if len(line) > 120:
                analysis['code_smells'].append(f"Line {i}: Line too long ({len(line)} characters)")
            
            # TODO comments
            if 'TODO' in line or 'FIXME' in line:
                analysis['code_smells'].append(f"Line {i}: TODO/FIXME comment found")
            
            # Hardcoded passwords or keys
            if re.search(r'password\s*=\s*["\'][^"\']+["\']', line, re.IGNORECASE):
                analysis['security_issues'].append(f"Line {i}: Potential hardcoded password")
            
            if re.search(r'api_key\s*=\s*["\'][^"\']+["\']', line, re.IGNORECASE):
                analysis['security_issues'].append(f"Line {i}: Potential hardcoded API key")
            
            # Performance issues
            if '+=' in line and 'str' in line:
                analysis['performance_issues'].append(f"Line {i}: String concatenation in loop (use join() instead)")
        
        return analysis
    
    def generate_solutions(self, error_type, error_message, matched_patterns):
        """Generate potential solutions for the error"""
        solutions = []
        
        # Add solutions from matched patterns
        for pattern in matched_patterns:
            for solution in pattern['solutions']:
                solutions.append({
                    'type': 'pattern_match',
                    'description': solution,
                    'confidence': 0.8,
                    'pattern': pattern['name']
                })
        
        # Add solutions from solution database
        for solution_key, solution_info in self.solution_database.items():
            if solution_key.lower() in error_message.lower():
                solutions.append({
                    'type': 'database_match',
                    'description': solution_info['description'],
                    'solutions': solution_info['solutions'],
                    'code_fix': solution_info.get('code_fix'),
                    'confidence': 0.9
                })
        
        # Generic solutions based on error type
        generic_solutions = self.get_generic_solutions(error_type)
        solutions.extend(generic_solutions)
        
        # Sort by confidence
        solutions.sort(key=lambda x: x.get('confidence', 0.5), reverse=True)
        
        return solutions
    
    def get_generic_solutions(self, error_type):
        """Get generic solutions based on error type"""
        generic_solutions = {
            'ImportError': [
                {
                    'type': 'generic',
                    'description': 'Install missing package using pip',
                    'confidence': 0.7
                },
                {
                    'type': 'generic',
                    'description': 'Check Python path and virtual environment',
                    'confidence': 0.6
                }
            ],
            'AttributeError': [
                {
                    'type': 'generic',
                    'description': 'Check if object has the attribute using hasattr()',
                    'confidence': 0.7
                },
                {
                    'type': 'generic',
                    'description': 'Verify object type and available methods',
                    'confidence': 0.6
                }
            ],
            'ValueError': [
                {
                    'type': 'generic',
                    'description': 'Validate input data before processing',
                    'confidence': 0.7
                },
                {
                    'type': 'generic',
                    'description': 'Add input sanitization and validation',
                    'confidence': 0.6
                }
            ]
        }
        
        return generic_solutions.get(error_type, [])
    
    def attempt_auto_fix(self, debug_session):
        """Attempt to automatically fix the error"""
        if not self.auto_fix_enabled:
            return {'attempted': False, 'reason': 'Auto-fix disabled'}
        
        error_message = debug_session['error_message']
        file_path = debug_session['file_path']
        
        # Check if we have a known auto-fix for this error
        for solution in debug_session['solutions']:
            if solution.get('code_fix') and file_path:
                try:
                    # Apply the code fix
                    fix_result = self.apply_code_fix(file_path, solution['code_fix'], debug_session)
                    if fix_result['success']:
                        debug_session['auto_fix_applied'] = True
                        return fix_result
                except Exception as e:
                    logger.error(f"Error applying auto-fix: {e}")
        
        return {'attempted': True, 'success': False, 'reason': 'No applicable auto-fix found'}
    
    def apply_code_fix(self, file_path, code_fix, debug_session):
        """Apply a code fix to a file"""
        try:
            # Create backup
            backup_path = f"{file_path}.backup_{int(time.time())}"
            with open(file_path, 'r') as original:
                with open(backup_path, 'w') as backup:
                    backup.write(original.read())
            
            # Apply fix (this is a simplified implementation)
            # In practice, this would need more sophisticated code modification
            with open(file_path, 'r') as f:
                content = f.read()
            
            # Simple text replacement for demonstration
            # Real implementation would use AST manipulation
            if 'sqlite3.connect(' in content and 'timeout=' not in content:
                content = content.replace(
                    'sqlite3.connect(',
                    'sqlite3.connect('
                )
                # Add timeout parameter
                content = re.sub(
                    r'sqlite3\.connect\(([^)]+)\)',
                    r'sqlite3.connect(\1, timeout=30)',
                    content
                )
            
            with open(file_path, 'w') as f:
                f.write(content)
            
            return {
                'success': True,
                'backup_path': backup_path,
                'description': 'Applied database timeout fix'
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def store_debug_session(self, debug_session):
        """Store debug session in database"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO debug_sessions 
                    (session_id, error_type, error_message, stack_trace, file_path, 
                     line_number, resolution_status, auto_fixed)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    debug_session['session_id'],
                    debug_session['error_type'],
                    debug_session['error_message'],
                    debug_session['stack_trace'],
                    debug_session.get('file_path'),
                    debug_session.get('line_number'),
                    'analyzed',
                    debug_session.get('auto_fix_applied', False)
                ))
                
                conn.commit()
                
        except Exception as e:
            logger.error(f"Error storing debug session: {e}")
    
    def get_debug_report(self, session_id):
        """Get detailed debug report for a session"""
        if session_id in self.debug_sessions:
            return self.debug_sessions[session_id]
        
        # Try to load from database
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT * FROM debug_sessions WHERE session_id = ?
                ''', (session_id,))
                
                result = cursor.fetchone()
                if result:
                    # Convert to dictionary format
                    columns = [desc[0] for desc in cursor.description]
                    return dict(zip(columns, result))
                
        except Exception as e:
            logger.error(f"Error loading debug session: {e}")
        
        return None
    
    def get_error_statistics(self, days=30):
        """Get error statistics for the specified period"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Most common errors
                cursor.execute('''
                    SELECT error_type, COUNT(*) as count
                    FROM debug_sessions 
                    WHERE start_time > datetime('now', '-{} days')
                    GROUP BY error_type
                    ORDER BY count DESC
                    LIMIT 10
                '''.format(days))
                
                common_errors = cursor.fetchall()
                
                # Auto-fix success rate
                cursor.execute('''
                    SELECT 
                        COUNT(*) as total_sessions,
                        SUM(CASE WHEN auto_fixed = 1 THEN 1 ELSE 0 END) as auto_fixed_count
                    FROM debug_sessions 
                    WHERE start_time > datetime('now', '-{} days')
                '''.format(days))
                
                fix_stats = cursor.fetchone()
                
                return {
                    'period_days': days,
                    'common_errors': common_errors,
                    'total_sessions': fix_stats[0] if fix_stats else 0,
                    'auto_fixed_count': fix_stats[1] if fix_stats else 0,
                    'auto_fix_rate': (fix_stats[1] / fix_stats[0] * 100) if fix_stats and fix_stats[0] > 0 else 0
                }
                
        except Exception as e:
            logger.error(f"Error getting error statistics: {e}")
            return {}

# Global auto debugger instance
auto_debugger = AutoDebugger()

def analyze_error(error_type, error_message, stack_trace, file_path=None, line_number=None):
    """Analyze an error and get debugging information"""
    return auto_debugger.analyze_error(error_type, error_message, stack_trace, file_path, line_number)

def get_debug_report(session_id):
    """Get debug report for a session"""
    return auto_debugger.get_debug_report(session_id)

def get_error_statistics(days=30):
    """Get error statistics"""
    return auto_debugger.get_error_statistics(days)

