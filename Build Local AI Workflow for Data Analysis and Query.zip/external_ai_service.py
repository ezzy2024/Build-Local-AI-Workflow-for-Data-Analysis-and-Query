from openai import OpenAI
import os
import logging
import json
import hashlib
from datetime import datetime
import re

logger = logging.getLogger(__name__)

class ExternalAIService:
    """Service for secure external AI queries without exposing local data"""
    
    def __init__(self):
        self.setup_openai()
        self.privacy_filters = self.setup_privacy_filters()
        
    def setup_openai(self):
        """Setup OpenAI client"""
        try:
            api_key = os.getenv('OPENAI_API_KEY')
            api_base = os.getenv('OPENAI_API_BASE')
            
            if api_key:
                if api_base:
                    self.openai_client = OpenAI(api_key=api_key, base_url=api_base)
                else:
                    self.openai_client = OpenAI(api_key=api_key)
                self.openai_available = True
                logger.info("External AI service initialized")
            else:
                self.openai_available = False
                self.openai_client = None
                logger.warning("OpenAI API key not found. External AI queries will not work.")
                
        except Exception as e:
            logger.error(f"Error setting up external AI: {e}")
            self.openai_available = False
            self.openai_client = None
            
    def setup_privacy_filters(self):
        """Setup filters to prevent local data leakage"""
        return {
            # Patterns that might indicate local file paths
            'file_paths': [
                r'[A-Za-z]:\\[^\\]+\\',  # Windows paths
                r'/[^/\s]+/[^/\s]+/',    # Unix paths
                r'\\\\[^\\]+\\',         # UNC paths
                r'\\Users\\[^\\]+',      # Windows user directories
                r'/home/[^/]+',          # Linux home directories
                r'/Users/[^/]+',         # macOS user directories
            ],
            
            # Patterns for personal information
            'personal_info': [
                r'\b\d{3}-\d{2}-\d{4}\b',           # SSN
                r'\b\d{3}-\d{3}-\d{4}\b',           # Phone numbers
                r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',  # Email
                r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b',  # Credit card
                r'[Pp][Aa][Ss][Ss][Ww][Oo][Rr][Dd].*[A-Za-z0-9!@#$%^&*]{6,}',  # Passwords
                r'[Aa][Pp][Ii]_?[Kk][Ee][Yy].*[A-Za-z0-9]{20,}',  # API keys
                r'[Tt][Oo][Kk][Ee][Nn].*[A-Za-z0-9]{20,}',  # Tokens
            ],
            
            # Patterns for local network information
            'network_info': [
                r'\b(?:192\.168|10\.|172\.(?:1[6-9]|2[0-9]|3[01])\.)\d+\.\d+\b',  # Private IPs
                r'\b127\.0\.0\.1\b',                # Localhost
                r'\blocalhost\b',                   # Localhost name
                r'\.local\b',                       # Local domains
                r'\.lan\b',                         # LAN domains
                r'\b([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})\b',  # MAC addresses
            ],
            
            # Patterns for system information
            'system_info': [
                r'HKEY_[A-Z_]+\\.*',               # Windows registry keys
                r'-----BEGIN [A-Z ]+-----.*-----END [A-Z ]+-----',  # Private keys
                r'Computer\\[^\\]+',               # Computer names
                r'WORKGROUP\\[^\\]+',              # Workgroup names
            ]
        }
    
    def sanitize_query(self, query):
        """Sanitize query to remove potentially sensitive information"""
        sanitized = query
        
        # Apply all privacy filters
        for category, patterns in self.privacy_filters.items():
            for pattern in patterns:
                sanitized = re.sub(pattern, f"[{category.upper()}_REDACTED]", sanitized, flags=re.IGNORECASE)
        
        return sanitized
    
    def query_external_ai(self, user_query, local_context=None):
        """Query external AI with sanitized context"""
        try:
            if not self.openai_available:
                return "External AI service is not available. Please check your API configuration."
            
            # Sanitize the query to remove sensitive information
            sanitized_query = self.sanitize_query(user_query)
            
            # Create a general context summary without exposing specific local data
            context_summary = self.create_safe_context_summary(local_context)
            
            # Prepare the prompt for external AI
            system_prompt = """You are a helpful AI assistant. The user has a local document analysis system and is asking questions that may relate to their documents. 
            
            Provide helpful, general information and guidance. Do not ask for or reference specific file contents, paths, or personal information.
            
            If the user's question seems to relate to document analysis, provide general advice about document analysis techniques, tools, or methodologies."""
            
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Context: {context_summary}\n\nQuestion: {sanitized_query}"}
            ]
            
            response = self.openai_client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=messages,
                max_tokens=500,
                temperature=0.7
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            logger.error(f"Error querying external AI: {e}")
            return "I encountered an error while processing your external query."
            
    def sanitize_text(self, text):
        """Remove sensitive information from text"""
        try:
            if not text:
                return ""
            
            sanitized = text
            
            # Apply privacy filters
            for category, patterns in self.privacy_filters.items():
                for pattern in patterns:
                    sanitized = re.sub(pattern, f"[{category.upper()}_REDACTED]", sanitized, flags=re.IGNORECASE)
            
            # Remove potential file names (anything that looks like filename.extension)
            sanitized = re.sub(r'\b\w+\.\w{2,4}\b', '[FILENAME_REDACTED]', sanitized)
            
            # Remove potential usernames or computer names
            sanitized = re.sub(r'\\\\[^\\]+\\', '[NETWORK_PATH_REDACTED]\\', sanitized)
            
            return sanitized
            
        except Exception as e:
            logger.error(f"Error sanitizing text: {e}")
            return "[SANITIZATION_ERROR]"
            
    def create_safe_context_summary(self, local_context):
        """Create a safe summary of local context without exposing sensitive data"""
        try:
            if not local_context:
                return "User has a local document analysis system."
            
            summary_parts = []
            
            # Count file types without revealing specific files
            file_types = {}
            total_files = len(local_context)
            
            for ctx in local_context:
                file_type = ctx.get('file_type', 'unknown')
                file_types[file_type] = file_types.get(file_type, 0) + 1
            
            summary_parts.append(f"User has {total_files} relevant files in their local system.")
            
            if file_types:
                type_summary = ", ".join([f"{count} {ftype} files" for ftype, count in file_types.items()])
                summary_parts.append(f"File types: {type_summary}.")
            
            # General content themes without specific details
            has_text_content = any(ctx.get('content') for ctx in local_context)
            if has_text_content:
                summary_parts.append("Some files contain text content that has been analyzed.")
            
            return " ".join(summary_parts)
            
        except Exception as e:
            logger.error(f"Error creating safe context summary: {e}")
            return "User has a local document analysis system."
            
    def search_external_knowledge(self, query, domain=None):
        """Search for general knowledge without exposing local context"""
        try:
            if not self.openai_available:
                return "External search is not available."
            
            sanitized_query = self.sanitize_text(query)
            
            system_prompt = """You are a knowledgeable assistant that provides factual information and general guidance. 
            
            Provide accurate, helpful information based on your training data. Do not ask for or reference specific personal files or local information."""
            
            if domain:
                system_prompt += f" Focus your response on the {domain} domain."
            
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": sanitized_query}
            ]
            
            response = self.openai_client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=messages,
                max_tokens=600,
                temperature=0.5
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            logger.error(f"Error searching external knowledge: {e}")
            return "I encountered an error while searching for external information."
            
    def get_general_advice(self, topic):
        """Get general advice on a topic without local context"""
        try:
            if not self.openai_available:
                return "External advice service is not available."
            
            sanitized_topic = self.sanitize_text(topic)
            
            system_prompt = """You are an expert advisor that provides general guidance and best practices. 
            
            Provide helpful, actionable advice based on general knowledge and best practices. Keep responses practical and informative."""
            
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Please provide general advice about: {sanitized_topic}"}
            ]
            
            response = self.openai_client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=messages,
                max_tokens=400,
                temperature=0.6
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            logger.error(f"Error getting general advice: {e}")
            return "I encountered an error while getting advice."
            
    def validate_query_safety(self, query):
        """Validate that a query is safe to send externally"""
        try:
            # Check for obvious sensitive patterns
            for category, patterns in self.privacy_filters.items():
                for pattern in patterns:
                    if re.search(pattern, query, re.IGNORECASE):
                        return False, f"Query contains potentially sensitive {category} information"
            
            # Check for file-like patterns
            if re.search(r'\b\w+\.\w{2,4}\b', query):
                return False, "Query contains potential file names"
            
            # Check for very specific local references
            local_indicators = ['my file', 'my document', 'this file', 'local', 'on my computer']
            if any(indicator in query.lower() for indicator in local_indicators):
                return False, "Query contains local system references"
            
            return True, "Query appears safe for external processing"
            
        except Exception as e:
            logger.error(f"Error validating query safety: {e}")
            return False, "Error validating query safety"
            
    def get_privacy_report(self):
        """Get a report on privacy protection measures"""
        return {
            'privacy_filters_active': len(self.privacy_filters),
            'sanitization_enabled': True,
            'external_ai_available': self.openai_available,
            'data_isolation': 'All local data is filtered before external queries',
            'last_updated': datetime.utcnow().isoformat()
        }

